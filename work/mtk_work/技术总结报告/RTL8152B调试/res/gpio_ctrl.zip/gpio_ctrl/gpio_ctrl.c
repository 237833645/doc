#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>

#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <linux/input.h>

#include "gpio_ctrl.h"


/**

*/

static struct pinctrl *gpio_ctrl_pin_ctrl= NULL;
static struct pinctrl_state *gpio_ctrl_1_high  = NULL;
static struct pinctrl_state *gpio_ctrl_1_low = NULL;
static struct pinctrl_state *gpio_ctrl_2_high  = NULL;
static struct pinctrl_state *gpio_ctrl_2_low = NULL;
static struct pinctrl_state *gpio_ctrl_3_high  = NULL;
static struct pinctrl_state *gpio_ctrl_3_low = NULL;
static struct pinctrl_state *gpio_ctrl_4_high  = NULL;
static struct pinctrl_state *gpio_ctrl_4_low = NULL;
static struct pinctrl_state *gpio_ctrl_5_high  = NULL;
static struct pinctrl_state *gpio_ctrl_5_low = NULL;

static dev_t gpio_ctrl_devno;
static struct class *gpio_ctrl_class = NULL;
static struct device *gpio_ctrl_devices = NULL;
#define GPIO_CTRL_DEVNAME            "gpio_ctrl"


static int gpio_ctrl_pinctrl_init(struct platform_device *pdev)
{
	int ret = 0;
	GPIO_CTRL_FUNC();
	gpio_ctrl_pin_ctrl = devm_pinctrl_get(&pdev->dev);
	if (IS_ERR(gpio_ctrl_pin_ctrl)) {
		dev_err(&pdev->dev, "Cannot find gpio_ctrl_pin_ctrl!");
		ret = PTR_ERR(gpio_ctrl_pin_ctrl);
		printk("%s devm_pinctrl_get fail!\n", __func__);
	}
	
	/*ctrl 1 */
	gpio_ctrl_1_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_1_high");
	if (IS_ERR(gpio_ctrl_1_high)) {
		ret = PTR_ERR(gpio_ctrl_1_high);
		printk("%s : pinctrl err, gpio_ctrl_1_high\n", __func__);
	}

	gpio_ctrl_1_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_1_low");
	if (IS_ERR(gpio_ctrl_1_low)) {
		ret = PTR_ERR(gpio_ctrl_1_low);
		printk("%s : pinctrl err, gpio_ctrl_1_low\n", __func__);
	}
	
	/*ctrl 2 */
	gpio_ctrl_2_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_2_high");
	if (IS_ERR(gpio_ctrl_2_high)) {
		ret = PTR_ERR(gpio_ctrl_2_high);
		printk("%s : pinctrl err, gpio_ctrl_2_high\n", __func__);
	}

	gpio_ctrl_2_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_2_low");
	if (IS_ERR(gpio_ctrl_2_low)) {
		ret = PTR_ERR(gpio_ctrl_2_low);
		printk("%s : pinctrl err, gpio_ctrl_2_low\n", __func__);
	}
	
	/*ctrl 3 */
	gpio_ctrl_3_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_3_high");
	if (IS_ERR(gpio_ctrl_3_high)) {
		ret = PTR_ERR(gpio_ctrl_3_high);
		printk("%s : pinctrl err, gpio_ctrl_3_high\n", __func__);
	}

	gpio_ctrl_3_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_3_low");
	if (IS_ERR(gpio_ctrl_3_low)) {
		ret = PTR_ERR(gpio_ctrl_3_low);
		printk("%s : pinctrl err, gpio_ctrl_3_low\n", __func__);
	}
	
	/*ctrl 4 */	
	gpio_ctrl_4_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_4_high");
	if (IS_ERR(gpio_ctrl_4_high)) {
		ret = PTR_ERR(gpio_ctrl_4_high);
		printk("%s : pinctrl err, gpio_ctrl_4_high\n", __func__);
	}

	gpio_ctrl_4_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_4_low");
	if (IS_ERR(gpio_ctrl_4_low)) {
		ret = PTR_ERR(gpio_ctrl_4_low);
		printk("%s : pinctrl err, gpio_ctrl_4_low\n", __func__);
	}
	
	/*ctrl 5 */	
	gpio_ctrl_5_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_5_high");
	if (IS_ERR(gpio_ctrl_5_high)) {
		ret = PTR_ERR(gpio_ctrl_5_high);
		printk("%s : pinctrl err, gpio_ctrl_5_high\n", __func__);
	}

	gpio_ctrl_5_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_5_low");
	if (IS_ERR(gpio_ctrl_5_low)) {
		ret = PTR_ERR(gpio_ctrl_5_low);
		printk("%s : pinctrl err, gpio_ctrl_5_low\n", __func__);
	}
	
	return ret;
}

static ssize_t gpio_ctrl_set_en(struct device *dev,struct device_attribute *attr, const char *buf, size_t count)
{
    int status = 0;
	int pinctrl_num = 0;
	GPIO_CTRL_FUNC();
	sscanf(buf, "%d %d", &pinctrl_num, &status);
	
	if(gpio_ctrl_pin_ctrl == NULL){
		printk("\n\n\n\n\ gpio_ctrl_pin_ctrl == 0 Ponit Error !!!!!!!!!!!!! \n\n\n\n");
		return -1;
	}
	
    if(status){
		switch (pinctrl_num){
			case 1:
				if(gpio_ctrl_1_high != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_high);
				break;
			case 2:
				if(gpio_ctrl_2_high != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_high);
				break;
			case 3:
				if(gpio_ctrl_3_high != 0)			
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_high);
				break;
			case 4:
				if(gpio_ctrl_4_high != 0)						
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_high);
				break;
			case 5:
				if(gpio_ctrl_5_high != 0)									
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_high);
				break;
			default:
				break;
		}
        
    } else {
		switch (pinctrl_num){
			case 1:
				if(gpio_ctrl_1_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_low);
				break;
			case 2:
				if(gpio_ctrl_2_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_low);
				break;
			case 3:
				if(gpio_ctrl_3_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_low);
				break;
			case 4:
				if(gpio_ctrl_4_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_low);
				break;
			case 5:
				if(gpio_ctrl_5_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_low);
				break;
			default:
				break;
		}
    }
    return count;
}

static ssize_t gpio_ctrl_get_en(struct device *dev, struct device_attribute *attr, char *buf)
{
	//unsigned char reg_val;
	ssize_t len = 0;
	//u8 i;
	//for (i = 0; i < 0x30; i++)
	//{
	//	reg_val = i2c_read_reg(i);
	//	len += snprintf(buf + len, PAGE_SIZE - len, "reg%2X = 0x%2X,\n", i, reg_val);
	//}

	return len;
}


static DEVICE_ATTR(gpio_ctrl_en, 0660, gpio_ctrl_get_en,  gpio_ctrl_set_en);

static struct device_attribute *gpio_ctrl_attr_list[] = {
    &dev_attr_gpio_ctrl_en,
};

static int gpio_ctrl_create_attr(struct device *dev)
{
    int idx, err = 0;
	GPIO_CTRL_FUNC();
    int num =
        (int) sizeof(gpio_ctrl_attr_list) /
        sizeof(gpio_ctrl_attr_list[0]);

    if (!dev)
        return -EINVAL;

    for (idx = 0; idx < num; idx++) {
        device_create_file(dev, gpio_ctrl_attr_list[idx]);
    }

    return err;
}


static int gpio_ctrl_probe(struct platform_device *pdev)
{
	int ret = 0;

	GPIO_CTRL_FUNC();
	
	ret = gpio_ctrl_pinctrl_init(pdev);
	if (ret != 0) {
		printk("[%s] failed to init gpio_ctrl pinctrl.\n", __func__);
		return ret;
	} else {
		printk("[%s] Success to init gpio_ctrl pinctrl.\n", __func__);
	}

	ret = alloc_chrdev_region(&gpio_ctrl_devno,0,1,GPIO_CTRL_DEVNAME);
	if(ret){
        printk("[gpio_ctrl] alloc_chrdev_region fail: %d\n", ret);
        goto exit_check_functionality_failed;
    }else{
        printk("[gpio_ctrl] major: %d, minor: %d\n",
               MAJOR(gpio_ctrl_devno), MINOR(gpio_ctrl_devno));
    }

	gpio_ctrl_class = class_create(THIS_MODULE,"gpio_ctrl");
    if (IS_ERR(gpio_ctrl_class)) {
        printk("[gpio_ctrl_probe] Unable to create class, err = %d\n",(int) PTR_ERR(gpio_ctrl_class));
        goto exit_check_functionality_failed;
    }
	
    gpio_ctrl_devices = (struct device *)device_create(gpio_ctrl_class, NULL, gpio_ctrl_devno, NULL, GPIO_CTRL_DEVNAME);
    if (NULL == gpio_ctrl_devices) {
        printk("[gpio_ctrl_probe] device_create fail\n");
        goto exit_check_functionality_failed;
    }

	
    if (gpio_ctrl_create_attr(gpio_ctrl_devices))
        printk("[gpio_ctrl_probe] create_attr fail\n");

		
	return 0;
	
	exit_check_functionality_failed:
	return ret; 

}


static int gpio_ctrl_remove(struct platform_device *pdev)
{
	GPIO_CTRL_FUNC();
	return 0;
}

#ifdef CONFIG_OF
	static const struct of_device_id gpio_ctrl_of_match[] = {
		{ .compatible = "mediatek,gpio_ctrl",},
		{},
};
#endif

const struct dev_pm_ops gpio_ctrl_pm_os = {
	.suspend = NULL,
	.resume = NULL,
};

static struct platform_driver gpio_ctrl_driver = {
	.probe = gpio_ctrl_probe,
	.shutdown = NULL,
	.remove = gpio_ctrl_remove,
	.driver = {
		.owner = THIS_MODULE,
		.name = "gpio_ctrl",
		.pm = &gpio_ctrl_pm_os,
		#ifdef CONFIG_OF
		.of_match_table = gpio_ctrl_of_match,
		#endif
	}
};

static int gpio_ctrl_mod_init(void)
{
	GPIO_CTRL_FUNC();
	if(platform_driver_register(&gpio_ctrl_driver)!=0)
		{
		GPIO_CTRL_DEBUG("unable to register gpio_ctrl driver\n");
		return -1;
	}
	return 0;
}

static void gpio_ctrl_mode_exit(void){
	GPIO_CTRL_FUNC();
	platform_driver_unregister(&gpio_ctrl_driver);
}

module_init(gpio_ctrl_mod_init);
module_exit(gpio_ctrl_mode_exit);

MODULE_DESCRIPTION("Rinlink gpio_gpio_ctrl driver");
MODULE_AUTHOR("maoweihua@rinlink.vip");
MODULE_LICENSE("GPL");

