#define GPIO_CTRL_DEBUG_CODE
#define GPIO_CTRL_DEVICE "GPIO_CTRL"

#ifdef GPIO_CTRL_DEBUG_CODE
#undef GPIO_CTRL_DEBUG
#define GPIO_CTRL_DEBUG(a,arg...) pr_err(GPIO_CTRL_DEVICE ": " a, ##arg)
#define GPIO_CTRL_FUNC()	pr_err(GPIO_CTRL_DEVICE ": %s line=%d\n", __func__, __LINE__)
#else
#define GPIO_CTRL_DEBUG(arg...)
#define GPIO_CTRL_FUNC()
#endif
