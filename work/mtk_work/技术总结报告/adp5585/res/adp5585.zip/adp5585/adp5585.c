/**************************************************************************
*  adp5585_key.c
* 
*  Create Date : 
* 
*  Modify Date : 
*
*  Create by   : AWINIC Technology CO., LTD
*
*  Version     : 0.9, 2016/02/15
**************************************************************************/
#include <linux/i2c.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/irq.h>
#include <linux/platform_device.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/init.h>
#include <linux/dma-mapping.h>
#include <linux/moduleparam.h>
#include <linux/mutex.h>
#include <linux/wakelock.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/input.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/miscdevice.h>
#include <linux/workqueue.h>
#include <linux/hrtimer.h>

#include "adp5585.h"

//#define ADP5585KEY_NAME      "subkey"
#define ADP5585_I2C_NAME		"ADP5585_KEY" 
//#define SET_SUBKEY_TEST     _IO('a', 31)


//reg list
#define P0_INPUT    0x00
#define P1_INPUT    0x01
#define P0_OUTPUT   0x02
#define P1_OUTPUT   0x03
#define P0_CONFIG   0x04
#define P1_CONFIG   0x05
#define P0_INT      0x06
#define P1_INT      0x07
#define ID_REG      0x10
#define CTL_REG     0x11
#define P0_LED_MODE 0x12
#define P1_LED_MODE 0x13
#define P1_0_DIM0   0x20
#define P1_1_DIM0   0x21
#define P1_2_DIM0   0x22
#define P1_3_DIM0   0x23
#define P0_0_DIM0   0x24
#define P0_1_DIM0   0x25
#define P0_2_DIM0   0x26
#define P0_3_DIM0   0x27
#define P0_4_DIM0   0x28
#define P0_5_DIM0   0x29
#define P0_6_DIM0   0x2A
#define P0_7_DIM0   0x2B
#define P1_4_DIM0   0x2C
#define P1_5_DIM0   0x2D
#define P1_6_DIM0   0x2E
#define P1_7_DIM0   0x2F
#define SW_RSTN     0x7F

#define P0_KROW_MASK 0xFF
#define P1_KCOL_MASK 0xF0
#define P1_LED_MASK  0x00

#define KROW_P0_0 0
#define KROW_P0_1 1
#define KROW_P0_2 2
#define KROW_P0_3 3
#define KROW_P0_4 4
#define KROW_P0_5 5
#define KROW_P0_6 6
#define KROW_P0_7 7

#define KROW_P1_0 0
#define KROW_P1_1 1
#define KROW_P1_2 2
#define KROW_P1_3 3
#define KROW_P1_4 4
#define KROW_P1_5 5
#define KROW_P1_6 6
#define KROW_P1_7 7


typedef struct{
    char name[10];
    int key_code;
    int key_val;
    int row;
    int col;
}KEY_STATE;

/****************************************************************************/
KEY_STATE key_map[]={
//TODO
//  name        code                    val     row         col
    {"6",      KEY_6,               0,  KROW_P0_0,  KROW_P1_4},  //
    {"9",      KEY_9,               0,  KROW_P0_1,  KROW_P1_4},  //
    {"#",      KEY_KBDILLUMTOGGLE,  0,  KROW_P0_2,  KROW_P1_4},  //
    {"RIGHT",  KEY_RIGHT,           0,  KROW_P0_3,  KROW_P1_4},  //
    {"MENU",   KEY_MENU,            0,  KROW_P0_4,  KROW_P1_4},  //

    {"0",      KEY_0,               0,  KROW_P0_0,  KROW_P1_5},  //
    {"8",      KEY_8,               0,  KROW_P0_1,  KROW_P1_5},  //
    {"2",      KEY_2,               0,  KROW_P0_2,  KROW_P1_5},  //
    {"1",      KEY_1,               0,  KROW_P0_3,  KROW_P1_5},  //
    {"5",      KEY_5,               0,  KROW_P0_4,  KROW_P1_5},  //

    {"*",      KEY_SWITCHVIDEOMODE, 0,  KROW_P0_0,  KROW_P1_6},  //
    {"7",      KEY_7,               0,  KROW_P0_1,  KROW_P1_6},   //
    {"4",      KEY_4,               0,  KROW_P0_2,  KROW_P1_6},  //
    {"BACK",   KEY_BACK,            0,  KROW_P0_3,  KROW_P1_6},  //
    {"SEND",   KEY_SEND,            0,  KROW_P0_4,  KROW_P1_6},  //

    {"UP",     KEY_UP,              0,  KROW_P0_0,  KROW_P1_7},  //
    {"3",      KEY_3,               0,  KROW_P0_1,  KROW_P1_7},   //
    {"LEFT",   KEY_LEFT,            0,  KROW_P0_2,  KROW_P1_7},  //
    {"DOWN",   KEY_DOWN,            0,  KROW_P0_3,  KROW_P1_7},  //
    {"END",    KEY_END,             0,  KROW_P0_4,  KROW_P1_7},  //

    {"F1",     KEY_F1,              0,  KROW_P0_5,  KROW_P1_4},  //
    {"F2",     KEY_F2,              0,  KROW_P0_6,  KROW_P1_4},  //
    {"F3",     KEY_F3,              0,  KROW_P0_7,  KROW_P1_4},  //
};


#define P0_NUM_MAX		8
#define P1_NUM_MAX		8
#define KEYST_MAX		2
#define KEYST_OLD		0
#define KEYST_NEW		1
static unsigned char keyst_old[P1_NUM_MAX];
static unsigned char keyst_new[P1_NUM_MAX];
static unsigned char keyst_def[KEYST_MAX][P1_NUM_MAX];


struct adp5585_key_data {
	struct input_dev	*input_dev;
	struct work_struct 	timer_work;
    struct delayed_work delay_work;
	struct device_node *irq_node;
	int irq;
};

struct pinctrl *adp5585_pin;
struct pinctrl_state *int_pin;

struct adp5585_key_data *adp5585_key;
struct i2c_client *adp5585_i2c_client;


#define HRTIMER_FRAME	20
struct hrtimer key_timer;


static ssize_t adp5585_get_reg(struct device* cd,struct device_attribute *attr, char* buf);
static ssize_t adp5585_set_reg(struct device* cd, struct device_attribute *attr,const char* buf, size_t len);


static int adp5585_read(struct i2c_client *client, u8 reg);
static int adp5585_write(struct i2c_client *client, u8 reg, u8 val);

static void adp5585_report_events(int ev_cnt);

#if 1
static int adp5585_read(struct i2c_client *client, u8 reg)
{
	unsigned char ret;
	u8 rdbuf[512] = {0};

    //mutex_lock(&read_write_lock);
	struct i2c_msg msgs[] = {
		{
			.addr	= adp5585_i2c_client->addr,
			.flags	= 0,
			.len	= 1,
			.buf	= rdbuf,
		},
		{
			.addr	= adp5585_i2c_client->addr,
			.flags	= I2C_M_RD,
			.len	= 1,
			.buf	= rdbuf,
		},
	};

	rdbuf[0] = reg;
	
	ret = i2c_transfer(adp5585_i2c_client->adapter, msgs, 2);
	if (ret < 0)
		pr_err("msg %s i2c read error: %d\n", __func__, ret);
    //mutex_unlock(&read_write_lock);

    return rdbuf[0];

}

static int adp5585_write(struct i2c_client *client, u8 reg, u8 val)
{
    char ret;
	u8 wdbuf[512] = {0};

    //mutex_lock(&read_write_lock);
	struct i2c_msg msgs[] = {
		{
			.addr	= adp5585_i2c_client->addr,
			.flags	= 0,
			.len	= 2,
			.buf	= wdbuf,
		},
	};

	wdbuf[0] = reg;
	wdbuf[1] = val;

	ret = i2c_transfer(adp5585_i2c_client->adapter, msgs, 1);
	if (ret < 0)
		pr_err("msg %s i2c read error: %d\n", __func__, ret);
    //mutex_unlock(&read_write_lock);

    return ret;
}

#else

static int adp5585_read(struct i2c_client *client, u8 reg)
{
	int ret = i2c_smbus_read_byte_data(client, reg);

	if (ret < 0)
		dev_err(&client->dev, "Read Error\n");

	return ret;
}

static int adp5585_write(struct i2c_client *client, u8 reg, u8 val)
{
	return i2c_smbus_write_byte_data(client, reg, val);
}


#endif




static enum hrtimer_restart adp5585_key_timer_func(struct hrtimer *timer)
{
    printk("%s enter\n", __func__);

    schedule_work(&adp5585_key->timer_work);

    return HRTIMER_NORESTART;
}

static void adp5585_eint_work(struct work_struct *work)
{
    hrtimer_start(&key_timer, ktime_set(0,(1000/HRTIMER_FRAME)*1000000), HRTIMER_MODE_REL);
}
/*****************************************************************
** Interrupt
******************************************************************/
static void adp5585_key_timer_work(struct work_struct *work)
{
//TODO
    unsigned char i,j,cnt;
    unsigned char val = 0;
    int keymap_len;
	u32 event = 0;
	int ev_cnt, status;

    printk("%s: begin \n", __func__);


	status = adp5585_read(adp5585_i2c_client, ADP5585_INT_STATUS);

	printk("%s: ADP5585_INT_STATUS = %x  \n", __func__, status);

	if (status & OVRFLOW_INT)	/* Unlikely and should never happen */
		dev_err(&adp5585_i2c_client->dev, "Event Overflow Error\n");

	if (status & EVENT_INT) {
		ev_cnt = adp5585_read(adp5585_i2c_client, ADP5585_STATUS) & KEC;
		if (ev_cnt) {
			adp5585_report_events(ev_cnt);
			input_sync(adp5585_key->input_dev);  
		}
	}
	adp5585_write(adp5585_i2c_client, ADP5585_INT_STATUS, status);	/* Status is W1C */


#if 0	
    keymap_len = sizeof(key_map)/sizeof(KEY_STATE);

    for (i=0; i<P1_NUM_MAX; i++) {
        if (P1_KCOL_MASK & (1<<i)) {
            //val = i2c_read_reg(P1_CONFIG);
            printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
            //i2c_write_reg(P1_CONFIG, (P1_KCOL_MASK | val) & (~(1<<i)));  //set p1_x port output mode
            //val = i2c_read_reg(P1_OUTPUT);
            printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
            //i2c_write_reg(P1_OUTPUT, (P1_KCOL_MASK | val) & (~(1<<i)));

            //val = i2c_read_reg(P0_INPUT);                // read p0 port status
            printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
            keyst_new[i] = (val & P0_KROW_MASK);
            printk("0x%02x, ", keyst_new[i]);                //i=p1 keyst[i]=p0
        }
    }
    printk("\n");
    if (memcmp(keyst_old, keyst_new, P1_NUM_MAX)) { // keyst changed
        for (i=0; i<P1_NUM_MAX; i++) {
            if (keyst_old[i] != keyst_new[i])
            {       // keyst of i col changed
                for (j=0; j<P0_NUM_MAX; j++)
                {
                    if (P0_KROW_MASK & (1<<j))
                    {                               // j row gpio used
                        if ((keyst_old[i] & (1<<j)) != (keyst_new[i] & (1<<j))) {               // j row & i col changed
                            for (cnt=0; cnt<keymap_len; cnt++) {        // find row&col in the keymap
                                if ((key_map[cnt].row == j) && (key_map[cnt].col == i))
                                    break;
                            }
                            if (keyst_new[i] & (1<<j)) {                // release
                                key_map[cnt].key_val = 0;
                            } else {                                        // press
                                key_map[cnt].key_val = 1;
                            }
                            input_report_key(adp5585_key->input_dev, key_map[cnt].key_code, key_map[cnt].key_val);
                            input_sync(adp5585_key->input_dev);
                            printk("%s: key_report: p0-row=%d, p1-col=%d, key_code=%d, key_val=%d\n",
                                    __func__, j, i, key_map[cnt].key_code, key_map[cnt].key_val);
                        }
                    }
                }
            }
        }
        memcpy(keyst_old, keyst_new, P1_NUM_MAX);
    }

    if(!(memcmp(&keyst_new[0], &keyst_def[KEYST_NEW][0], P1_NUM_MAX))) {            // all key release
        //val = i2c_read_reg(P1_CONFIG);
        printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
        //i2c_write_reg(P1_CONFIG, val & (~P1_KCOL_MASK));  //set p1 port output mode

        //val = i2c_read_reg(P1_OUTPUT);
        printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
        //i2c_write_reg(P1_OUTPUT, val & (~P1_KCOL_MASK)); //p1 port output 0

        //val = i2c_read_reg(P0_INPUT);                    //clear p0 input irq
        printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);

        //val = i2c_read_reg(P0_INT);
        printk("%s:%d:val = 0x%x\n",__func__,__LINE__,val);
        //i2c_write_reg(P0_INT, val & (~P0_KROW_MASK));    //enable p0 port irq
        //i2c_write_reg(P0_INT, 0xff & (~P0_KROW_MASK));   //enable p0 port irq

       // enable_irq(adp5585_key->irq);                                    //enable bb irq
        printk("%s:enable_irq\n",__func__);

        return;
    }
#endif
	//enable_irq(adp5585_key->irq); 

    hrtimer_start(&key_timer, ktime_set(0,(1000/HRTIMER_FRAME)*1000000), HRTIMER_MODE_REL);


	
    printk("%s: end \n", __func__);
}


static void adp5585_report_events(int ev_cnt)
{
	int i, j;
	
	

	for (i = 0; i < ev_cnt; i++) {
		int key = adp5585_read(adp5585_i2c_client, ADP5585_FIFO_1 + i);
		int key_val = key & KEY_EV_MASK;

		
		switch (key_val)
		{	
			case 4:
				printk("%s key 1\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_1, key & KEY_EV_PRESSED);
				}
			break;
			case 3:
				printk("%s key 2\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_2, key & KEY_EV_PRESSED);
				}		
			break;
			case 2:
				printk("%s key 3\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_3, key & KEY_EV_PRESSED);
				}				
			break;
			case 13:
				printk("%s key a\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_A, key & KEY_EV_PRESSED);
				}				
			break;
			case 23:
				printk("%s key 4\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_4, key & KEY_EV_PRESSED);
				}				
			break;
			case 10:
				printk("%s key 5\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_5, key & KEY_EV_PRESSED);
				}					
			break;
			case 9:
				printk("%s key 6\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_6, key & KEY_EV_PRESSED);
				}					
			break;
			case 12:
				printk("%s key b\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_B, key & KEY_EV_PRESSED);
				}				
			break;
			case 8:
				printk("%s key 7\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_7, key & KEY_EV_PRESSED);
				}					
			break;
			case 7:
				printk("%s key 8\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_8, key & KEY_EV_PRESSED);
				}					
			break;
			case 6:
				printk("%s key 9\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_9, key & KEY_EV_PRESSED);
				}					
			break;
			case 11:
				printk("%s key c\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_C, key & KEY_EV_PRESSED);
				}			
			break;
			case 15:
				printk("%s key *\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_SWITCHVIDEOMODE, key & KEY_EV_PRESSED);
				}				
			break;
			case 5:
				printk("%s key 0\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_0, key & KEY_EV_PRESSED);
				}						
			break;
			case 14:
				printk("%s key #\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_KBDILLUMTOGGLE, key & KEY_EV_PRESSED);
				}										
			break;			
			case 20:
				printk("%s key d\n",__func__);
				if (key_val >= ADP5585_GPI_PIN_BASE &&
		    		key_val <= ADP5585_GPI_PIN_END) {
				} else {
					input_report_key(adp5585_key->input_dev, KEY_D, key & KEY_EV_PRESSED);
				}						
			break;
			
			default:
				break;
		}
		//printk("%s /t/t	i = [%d] key = %x, key_val = %x\n",__func__,i,key,key_val);
	}
}


static irqreturn_t adp5585_key_eint_func(int irq, void *desc)
{	
    int delay = 50;
	int status, ev_cnt;

	if(adp5585_key == NULL){
		printk("adp5585_key == NULL");
		return  IRQ_NONE;
	}



#if 0

	//enable_irq(adp5585_key->irq);

	#if 0
	status = adp5585_read(adp5585_i2c_client, ADP5585_INT_STATUS);

	if (status & OVRFLOW_INT)	/* Unlikely and should never happen */
		dev_err(&adp5585_i2c_client->dev, "Event Overflow Error\n");

	if (status & EVENT_INT) {
		ev_cnt = adp5585_read(adp5585_i2c_client, ADP5585_STATUS) & KEC;
		if (ev_cnt) {
			adp5585_report_events(ev_cnt);
			//input_sync(adp5585_key->input_dev);  
		}
	}
	adp5585_write(adp5585_i2c_client, ADP5585_INT_STATUS, status);	/* Status is W1C */
	#endif
#else
	//disable_irq_nosync(adp5585_key->irq);
	printk("%s start", __func__);

	
	schedule_delayed_work(&adp5585_key->delay_work, msecs_to_jiffies(delay));
	
	//enable_irq(adp5585_key->irq);

	
#endif
	return IRQ_HANDLED;

}
int adp5585_key_setup_eint(void)
{
	int ret = 0;
	u32 ints[2] = {0, 0};

	printk("%s start\n", __func__);

	adp5585_key->irq_node = of_find_compatible_node(NULL, NULL, "mediatek,ADP5585-eint");
	if (adp5585_key->irq_node) {
		of_property_read_u32_array(adp5585_key->irq_node, "debounce", ints, ARRAY_SIZE(ints));
		printk("%s ints[0] = %d, ints[1] = %d!!\n", __func__, ints[0], ints[1]);

		adp5585_key->irq = irq_of_parse_and_map(adp5585_key->irq_node, 0);
		printk("%s irq = %d\n", __func__, adp5585_key->irq);
		if (!adp5585_key->irq) {
			printk("%s irq_of_parse_and_map fail!!\n", __func__);
			return -EINVAL;
		}
		
		if (request_irq(adp5585_key->irq, adp5585_key_eint_func, IRQF_TRIGGER_FALLING , "adp5585-eint", NULL)) {
			printk("%s IRQ LINE NOT AVAILABLE!!\n", __func__);
			return -EINVAL;
		}
	} else {
		printk("null irq node!!\n");
		return -EINVAL;
	}  

	printk("%s end\n", __func__);

    return 0;
}




/*****************************************************************************
**Debug sysfs
******************************************************************************/
static ssize_t adp5585_get_reg(struct device* cd,struct device_attribute *attr, char* buf)
{
	unsigned char reg_val;
	ssize_t len = 0;
	u8 i;
	for(i=0;i<0x3c;i++)
	{
		reg_val = adp5585_read(adp5585_i2c_client, i);
		len += snprintf(buf+len, PAGE_SIZE-len, "reg%2X = 0x%2X, ", i,reg_val);
	}

	return len;
}

static ssize_t adp5585_set_reg(struct device* cd, struct device_attribute *attr, const char* buf, size_t len)
{
	unsigned int databuf[2];
	if(2 == sscanf(buf,"%x %x",&databuf[0], &databuf[1]))
	{
		adp5585_write(adp5585_i2c_client, databuf[0],databuf[1]);
	}
	return len;
}

static DEVICE_ATTR(reg, 0660, adp5585_get_reg,  adp5585_set_reg);


static int adp5585_create_sysfs(struct i2c_client *client)
{
	int err;
	struct device *dev = &(client->dev);

	err = device_create_file(dev, &dev_attr_reg);

	return err;
}

/*****************************************************************************
**Input register
******************************************************************************/
static void adp5585_input_register(void)
{
	int err;
	unsigned int i = 0;
	struct input_dev *input_dev;
	struct adp5585_key_map *adp5585_key_map;

	printk("%s start\n", __func__);

	input_dev = input_allocate_device();
	if (!input_dev){
		err = -ENOMEM;
		printk("adp5585_input_register --> failed to allocate input device\n");
		goto exit_input_dev_alloc_failed;
	}
	
	adp5585_key->input_dev = input_dev;
	__set_bit(EV_KEY, input_dev->evbit);
	__set_bit(EV_SYN, input_dev->evbit);


	__set_bit(KEY_0, input_dev->keybit);
	__set_bit(KEY_1, input_dev->keybit);
	__set_bit(KEY_2, input_dev->keybit);
	__set_bit(KEY_3, input_dev->keybit);
	__set_bit(KEY_4, input_dev->keybit);
	__set_bit(KEY_5, input_dev->keybit);
	__set_bit(KEY_6, input_dev->keybit);
	__set_bit(KEY_7, input_dev->keybit);
	__set_bit(KEY_8, input_dev->keybit);
	__set_bit(KEY_9, input_dev->keybit);
	__set_bit(KEY_A, input_dev->keybit);
	__set_bit(KEY_B, input_dev->keybit);
	__set_bit(KEY_C, input_dev->keybit);
	__set_bit(KEY_D, input_dev->keybit);
	__set_bit(KEY_SWITCHVIDEOMODE, input_dev->keybit); 	// *
	__set_bit(KEY_KBDILLUMTOGGLE, input_dev->keybit);	// #

	//__clear_bit(KEY_RESERVED, input_dev->keybit);

	input_dev->name	= ADP5585_I2C_NAME;
	err = input_register_device(input_dev);
	if (err) {
		printk("input_register_device -- > adp5585_i2c_probe: failed to register input device\n");
		goto exit_input_register_device_failed;
	}	

	printk("%s end\n", __func__);

	
exit_input_dev_alloc_failed:
	//cancel_work_sync(&adp5585_key->timer_work);
exit_input_register_device_failed:
	input_free_device(input_dev);
}



static int adp5585_setup(void)
{
	struct i2c_client *client = adp5585_i2c_client;
	int i, ret;

	ret = adp5585_write(client, ADP5585_POLL_PTIME_CFG, 0x01); //wangfeng
	if (ret < 0) {
		dev_err(&client->dev, "Write Error\n");
		return ret;
	}
	mdelay(5);
	ret = adp5585_write(client, ADP5585_PIN_CONFIG_A, 0x1F);
	mdelay(5);
	if (ret < 0) {
		dev_err(&client->dev, "Write Error\n");
		return ret;
	}
	ret = adp5585_write(client, ADP5585_PIN_CONFIG_B, 0x1F);
	if (ret < 0) {
		dev_err(&client->dev, "Write Error\n");
		return ret;
	}
	mdelay(5);	
	ret = adp5585_write(client, ADP5585_GENERAL_CFG, 0xA2);
	if (ret < 0) {
		dev_err(&client->dev, "Write Error\n");
		return ret;
	}
	mdelay(5);
	ret = adp5585_write(client, ADP5585_INT_EN, 0x05);
	if (ret < 0) {
		dev_err(&client->dev, "Write Error\n");
		return ret;
	}
	mdelay(5);

	return 0;
}


static int adp5585_i2c_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	//unsigned char reg_value;
	int err = 0;
	//unsigned char cnt = 5;
	
	printk("%s start\n", __func__);

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		err = -ENODEV;
		goto exit_check_functionality_failed;
	}
	printk("%s: kzalloc\n", __func__);
	
	adp5585_key = kzalloc(sizeof(*adp5585_key), GFP_KERNEL);
	if (!adp5585_key)	{
		err = -ENOMEM;
		printk("%s adp5585_key kzalloc failed\n",__func__);
		goto exit_alloc_data_failed;
	}
	adp5585_i2c_client = client;

	if (adp5585_i2c_client == NULL) {
		printk("%s adp5585_i2c_client = NULL return -1 \n",__func__);	
		return -1;
	}
	
	i2c_set_clientdata(client, adp5585_key);
	
	// CHIP ID
	err = adp5585_read(client, ADP5585_ID);
	if (err < 0) {
		printk("%s i2c read ADP5585_ID failed\n", __func__);
	}
	
	printk("%s CHIP ID = %x\n",__func__, (u8)err & ADP5585_DEVICE_ID_MASK);	

	adp5585_input_register();

	err = adp5585_setup();
	if (err)
		goto exit_create_singlethread;


	//Interrupt
    INIT_DELAYED_WORK(&adp5585_key->delay_work, adp5585_eint_work);
	INIT_WORK(&adp5585_key->timer_work, adp5585_key_timer_work);
	


	adp5585_key_setup_eint();

	//device_init_wakeup(&client->dev, 1);

    hrtimer_init(&key_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    key_timer.function = adp5585_key_timer_func;
	
	adp5585_create_sysfs(client);

	printk("%s end\n", __func__);

	return err;

exit_create_singlethread:
	adp5585_i2c_client = NULL;
exit_alloc_data_failed:	
exit_check_functionality_failed:
	//cancel_work_sync(&adp5585_key->timer_work);
	//hrtimer_cancel(&key_timer);
	
	return err;	
}

static int adp5585_i2c_remove(struct i2c_client *client)
{
	struct adp5585_key_data *adp5585_key = i2c_get_clientdata(client);

	printk("%s enter\n", __func__);
	
	input_unregister_device(adp5585_key->input_dev);
	
	kfree(adp5585_key);
	
	adp5585_i2c_client = NULL;
	i2c_set_clientdata(client, NULL);

	return 0;
}

static const struct i2c_device_id adp5585_i2c_id[] = {
	{ ADP5585_I2C_NAME, 0 },
	{ }
};

#ifdef CONFIG_OF
static const struct of_device_id extgpio_of_match[] = {
	{.compatible = "mediatek,adp5585"},
	{},
};
#endif

static struct i2c_driver adp5585_i2c_driver = {
    .driver = {
    .name   = ADP5585_I2C_NAME,
#ifdef CONFIG_OF
    .of_match_table = extgpio_of_match,
#endif
		},
    .probe          = adp5585_i2c_probe,
    .remove         = adp5585_i2c_remove,
    .id_table       = adp5585_i2c_id,
};

#if 0
void adp5585key_auto_test_for_factorymode(void)
{
    printk("Enter adp5585key_auto_test_for_factorymode!\n");
    mdelay(1000);
    //adp5585key_factory_mode_handler();
}
#endif//wangfeng del

long adp5585key_dev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
    
#if 0//wangfeng del	
	case SET_SUBKEY_TEST:
        adp5585key_auto_test_for_factorymode();    /* API for adp5585 key factory mode auto-test */
        printk("[adp5585 key_auto_test_for_factorymode] test performed!!\n");
        break;

#endif//wangfeng del
    default:
        return -EINVAL;
    }

    return 0;
}


//int adp5585key_dev_open(struct inode *inode, struct file *file)
//{
//    return 0;
//}

//static const struct file_operations adp5585_dev_fops = {
//    .owner = THIS_MODULE,
//    .unlocked_ioctl = adp5585key_dev_ioctl,
//    .open = adp5585key_dev_open,
//};

//static struct miscdevice adp5585key_dev = {
//    .minor = MISC_DYNAMIC_MINOR,
//    .name = ADP5585KEY_NAME,
//    .fops = &adp5585_dev_fops,
//};


static int adp5585_key_remove(struct platform_device *pdev)
{
	printk("adp5585 remove\n");
	i2c_del_driver(&adp5585_i2c_driver);
	return 0;
}

static int adp5585_key_probe(struct platform_device *pdev)
{
	int ret;

	printk("%s start!\n", __func__);

#if 0//wangfeng del
	ret = adp5585_pinctrl_init(pdev);
	if (ret != 0) {
		printk("[%s] failed to init adp5585 pinctrl.\n", __func__);
		return ret;
	} else {
		printk("[%s] Success to init adp5585 pinctrl.\n", __func__);
	}
#endif//wangfeng del

	//adp5585key_dev.parent = &pdev->dev;
    //ret = misc_register(&adp5585key_dev);
    //if (ret) {
    //    printk("register device failed (%d)\n", ret);
    //    return ret;
    //}
	
	ret = i2c_add_driver(&adp5585_i2c_driver);
	if (ret != 0) {
		printk("[%s] failed to register adp5585 i2c driver.\n", __func__);
		return ret;
	} else {
		printk("[%s] Success to register adp5585 i2c driver.\n", __func__);
	}


	printk("%s end\n", __func__);

	return 0;
}

#ifdef CONFIG_OF
static const struct of_device_id adp5585_of_match[] = {
    {.compatible = "mediatek,platform_adp5585"},
    {},
};
#endif

static struct platform_driver adp5585_key_driver = {
    .probe	 = adp5585_key_probe,
    .remove	 = adp5585_key_remove,
    .driver = {
    .name   = "adp5585_key",
#ifdef CONFIG_OF
    .of_match_table = adp5585_of_match,
#endif
    }
};

static int __init adp5585_key_init(void) {
	int ret;
	printk("%s start\n", __func__);
	
	ret = platform_driver_register(&adp5585_key_driver);
	if (ret) {
		printk("****[%s] Unable to register driver (%d)\n", __func__, ret);
		return ret;
	}	

	printk("%s end\n", __func__);
	return 0;
}

static void __exit adp5585_key_exit(void) {
	printk("%s exit\n", __func__);
	platform_driver_unregister(&adp5585_key_driver);
}

module_init(adp5585_key_init);
module_exit(adp5585_key_exit);

MODULE_AUTHOR("<liweilei@awinic.com.cn>");
MODULE_DESCRIPTION("AWINIC adp5585 Key Driver");
MODULE_LICENSE("GPL");
