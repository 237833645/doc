/*
 * Analog Devices ADP5585 I/O Expander and QWERTY Keypad Controller
 *
 * Copyright 2010 Analog Devices Inc.
 *
 * Licensed under the GPL-2 or later.
 */

#ifndef _ADP5585_H
#define _ADP5585_H



#define ADP5585_ID					0x00
#define ADP5585_INT_STATUS			0x01
#define ADP5585_STATUS				0x02
#define ADP5585_FIFO_1				0x03
#define ADP5585_FIFO_2				0x04
#define ADP5585_FIFO_3				0x05
#define ADP5585_FIFO_4				0x06
#define ADP5585_FIFO_5				0x07
#define ADP5585_FIFO_6				0x08
#define ADP5585_FIFO_7				0x09
#define ADP5585_FIFO_8				0x0A
#define ADP5585_FIFO_9				0x0B
#define ADP5585_FIFO_10				0x0C
#define ADP5585_FIFO_11				0x0D
#define ADP5585_FIFO_12				0x0E
#define ADP5585_FIFO_13				0x0F
#define ADP5585_FIFO_14				0x10
#define ADP5585_FIFO_15				0x11
#define ADP5585_FIFO_16				0x12
#define ADP5585_GPI_INT_STAT_A		0x13
#define ADP5585_GPI_INT_STAT_B		0x14
#define ADP5585_GPI_STATUS_A		0x15
#define ADP5585_GPI_STATUS_B		0x16
#define ADP5585_RPULL_CONFIG_A		0x17
#define ADP5585_RPULL_CONFIG_B		0x18
#define ADP5585_RPULL_CONFIG_C		0x19
#define ADP5585_RPULL_CONFIG_D		0x1A
#define ADP5585_GPI_INT_LEVEL_A		0x1B
#define ADP5585_GPI_INT_LEVEL_B		0x1C
#define ADP5585_GPI_EVENT_EN_A		0x1D
#define ADP5585_GPI_EVENT_EN_B		0x1E
#define ADP5585_GPI_INTERRUPT_EN_A	0x1F
#define ADP5585_GPI_INTERRUPT_EN_B	0x20
#define ADP5585_DEBOUNCE_DIS_A		0x21
#define ADP5585_DEBOUNCE_DIS_B		0x22
#define ADP5585_GPO_DATA_OUT_A		0x23
#define ADP5585_GPO_DATA_OUT_B		0x24
#define ADP5585_GPO_OUT_MODE_A		0x25
#define ADP5585_GPO_OUT_MODE_B		0x26
#define ADP5585_GPIO_DIRECTION_A	0x27
#define ADP5585_GPIO_DIRECTION_B	0x28
#define ADP5585_RESET1_EVENT_A		0x29
#define ADP5585_RESET1_EVENT_B		0x2A
#define ADP5585_RESET1_EVENT_C		0x2B
#define ADP5585_RESET2_EVENT_A		0x2C
#define ADP5585_RESET2_EVENT_B		0x2D
#define ADP5585_RESET_CFG			0x2E
#define ADP5585_PWM_OFFT_LOW		0x2F
#define ADP5585_PWM_OFFT_HIGH		0x30
#define ADP5585_PWM_ONT_LOW			0x31
#define ADP5585_PWM_ONT_HIGH		0x32
#define ADP5585_PWM_CFG				0x33
#define ADP5585_LOGIC_CFG			0x34
#define ADP5585_LOGIC_FF_CFG		0x35
#define ADP5585_LOGIC_INT_EVENT_EN	0x36
#define ADP5585_POLL_PTIME_CFG		0x37
#define ADP5585_PIN_CONFIG_A		0x38
#define ADP5585_PIN_CONFIG_B		0x39
#define ADP5585_PIN_CONFIG_D		0x3A
#define ADP5585_GENERAL_CFG			0x3B
#define ADP5585_INT_EN				0x3C



/* ID Register */
#define ADP5585_DEVICE_ID_MASK		0xF
#define ADP5585_MAN_ID_MASK			0xF
#define ADP5585_MAN_ID_SHIFT		4
#define ADP5585_MAN_ID				0x02

/* GENERAL_CFG Register */
#define OSC_EN						(1 << 7)
#define CORE_CLK(x)					(((x) & 0x3) << 5)
#define INT_CFG						(1 << 1)
#define RST_CFG						(1 << 0)

/* INT_EN Register */
#define LOGIC_IEN	(1 << 4)
#define OVRFLOW_IEN	(1 << 2)
#define GPI_IEN		(1 << 1)
#define EVENT_IEN	(1 << 0)

/* Interrupt Status Register */
#define LOGIC_INT	(1 << 4)
#define OVRFLOW_INT	(1 << 2)
#define GPI_INT		(1 << 1)
#define EVENT_INT	(1 << 0)

/* STATUS Register */
#define LOGIC_STAT	(1 << 6)
#define KEC		0xF

/* PIN_CONFIG_D Register */
#define C4_EXTEND_CFG	(1 << 6)	/* RESET2 */
#define R4_EXTEND_CFG	(1 << 5)	/* RESET1 */

#define PTIME_MASK	0x3

/* Key Event Register xy */
#define KEY_EV_PRESSED		(1 << 7)
#define KEY_EV_MASK		0x7F

#define KEYP_MAX_EVENT		16

#define MAXGPIO			11 /* 10 on the ADP5585-01, 11 on ADP5585-02 */
#define ADP_BANK(offs)		((offs) > ADP_MAX_ROW_NUM)
#define ADP_BIT(offs)		(offs > ADP_MAX_ROW_NUM ? \
				1u << (offs - ADP_COL_SHIFT) : 1u << (offs))

/*
static const unsigned short adp5589_keymap[ADP5589_KEYMAPSIZE] = {
       [ADP5589_KEY(0, 0)]      = KEY_D,
       [ADP5589_KEY(0, 1)]      = KEY_C,
       [ADP5589_KEY(0, 2)]      = KEY_B,
       [ADP5589_KEY(0, 3)]      = KEY_A,
 
       [ADP5589_KEY(1, 0)]      = KEY_E,
       [ADP5589_KEY(1, 1)]      = KEY_9,
       [ADP5589_KEY(1, 2)]      = KEY_6,
       [ADP5589_KEY(1, 3)]      = KEY_3,
 
       [ADP5589_KEY(2, 0)]      = KEY_F,
       [ADP5589_KEY(2, 1)]      = KEY_8,
       [ADP5589_KEY(2, 2)]      = KEY_5,
       [ADP5589_KEY(2, 3)]      = KEY_2,
 
       [ADP5589_KEY(3, 0)]      = KEY_0,
       [ADP5589_KEY(3, 1)]      = KEY_7,
       [ADP5589_KEY(3, 2)]      = KEY_4,
       [ADP5589_KEY(3, 3)]      = KEY_1,
};
*/


#define ADP5585_KEYMAPSIZE	30

#define ADP5585_GPI_PIN_ROW0 37
#define ADP5585_GPI_PIN_ROW1 38
#define ADP5585_GPI_PIN_ROW2 39
#define ADP5585_GPI_PIN_ROW3 40
#define ADP5585_GPI_PIN_ROW4 41
#define ADP5585_GPI_PIN_ROW5 42
#define ADP5585_GPI_PIN_COL0 43
#define ADP5585_GPI_PIN_COL1 44
#define ADP5585_GPI_PIN_COL2 45
#define ADP5585_GPI_PIN_COL3 46
#define ADP5585_GPI_PIN_COL4 47
#define GPI_LOGIC 48

#define ADP5585_GPI_PIN_ROW_BASE ADP5585_GPI_PIN_ROW0
#define ADP5585_GPI_PIN_ROW_END ADP5585_GPI_PIN_ROW5
#define ADP5585_GPI_PIN_COL_BASE ADP5585_GPI_PIN_COL0
#define ADP5585_GPI_PIN_COL_END ADP5585_GPI_PIN_COL4

#define ADP5585_GPI_PIN_BASE ADP5585_GPI_PIN_ROW_BASE
#define ADP5585_GPI_PIN_END ADP5585_GPI_PIN_COL_END

#define ADP5585_GPIMAPSIZE_MAX (ADP5585_GPI_PIN_END - ADP5585_GPI_PIN_BASE + 1)


/* scan_cycle_time */
#define ADP5585_SCAN_CYCLE_10ms		0
#define ADP5585_SCAN_CYCLE_20ms		1
#define ADP5585_SCAN_CYCLE_30ms		2
#define ADP5585_SCAN_CYCLE_40ms		3

/* RESET_CFG */
#define RESET_PULSE_WIDTH_500us		0
#define RESET_PULSE_WIDTH_1ms		1
#define RESET_PULSE_WIDTH_2ms		2
#define RESET_PULSE_WIDTH_10ms		3

#define RESET_TRIG_TIME_0ms		(0 << 2)
#define RESET_TRIG_TIME_1000ms		(1 << 2)
#define RESET_TRIG_TIME_1500ms		(2 << 2)
#define RESET_TRIG_TIME_2000ms		(3 << 2)
#define RESET_TRIG_TIME_2500ms		(4 << 2)
#define RESET_TRIG_TIME_3000ms		(5 << 2)
#define RESET_TRIG_TIME_3500ms		(6 << 2)
#define RESET_TRIG_TIME_4000ms		(7 << 2)

#define RESET_PASSTHRU_EN		(1 << 5)
#define RESET1_POL_HIGH			(1 << 6)
#define RESET1_POL_LOW			(0 << 6)
#define RESET2_POL_HIGH			(1 << 7)
#define RESET2_POL_LOW			(0 << 7)

/* Mask Bits:
 * C C C C C | R R R R R R
 * 4 3 2 1 0 | 5 4 3 2 1 0
 *
 * ---- BIT -- -----------
 * 1 0 0 0 0 | 0 0 0 0 0 0
 * 0 9 8 7 6 | 5 4 3 2 1 0
 */

#define ADP_ROW_MASK		0x3F
#define ADP_COL_MASK		0x1F
#define ADP_ROW_SHIFT		0
#define ADP_COL_SHIFT		6
#define ADP_MAX_ROW_NUM		5
#define ADP_MAX_COL_NUM		4

#define ADP_ROW(x)		(1 << ((x) & ADP_ROW_MASK))
#define ADP_COL(x)		(1 << (((x) & ADP_COL_MASK) + ADP_COL_SHIFT))


#endif
