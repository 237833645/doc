#ifndef __LCD_GPIO_H__
#define __LCD_GPIO_H__

#if defined(BUILD_LK)
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#else
#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/i2c.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <mt-plat/mt_gpio.h>
#include <mach/gpio_const.h>
#include <linux/input.h>
#include <linux/printk.h>
#include <linux/proc_fs.h> //proc file use
#endif

#if defined(BUILD_LK)
#define MDELAY(n)   mdelay(n)  
#else
extern void msleep(unsigned int msecs);
#define MDELAY(n)   msleep(n)  
#endif

extern void gpio_lcd_init(void);
extern void gpio_lcd_powerup(void);
extern void gpio_lcd_powerdown(void);
extern void LT9211_RST(void);
extern void LT9211_POWERDOWN(void);
extern void OVP0921_RST(int ch);
extern void ISL_97900_RST(void);


#endif
