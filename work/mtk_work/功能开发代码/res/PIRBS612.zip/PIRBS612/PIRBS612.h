#define PIRBS612_DEBUG_CODE

#define PIRBS612_DEVICE "PIRBS612"
#ifdef PIRBS612_DEBUG_CODE
#undef PIRBS612_DEBUG
#define PIRBS612_DEBUG(a,arg...) pr_err(PIRBS612_DEVICE ": " a, ##arg)
#define PIRBS612_FUNC()	pr_err(PIRBS612_DEVICE ": %s line=%d\n", __func__, __LINE__)
#else
#define PIRBS612_DEBUG(arg...)
#define PIRBS612_FUNC()
#endif
