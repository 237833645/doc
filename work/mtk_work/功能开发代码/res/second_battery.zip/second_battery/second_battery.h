#define BATTERY_DEBUG_CODE

#define BATTERY_DEVICE "SEC_BATTERY"
#ifdef BATTERY_DEBUG_CODE
#undef BATTERY_DEBUG
#define BATTERY_DEBUG(a,arg...) pr_err(BATTERY_DEVICE ": " a, ##arg)
#define BATTERY_FUNC()	pr_err(BATTERY_DEVICE ": %s line=%d\n", __func__, __LINE__)
#else
#define BATTERY_DEBUG(arg...)
#define BATTERY_FUNC()
#endif
