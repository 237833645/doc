#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>

#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <linux/input.h>

#include "second_battery.h"

static int sec_battery_gpio = 0;
static int sec_chargeing_on = 0;
static int sec_bat_gpio = 0;
static int sec_bat_irq = 0;


extern bool upmu_is_chr_det(void);
extern int pinctrl_select_state(struct pinctrl *p, struct pinctrl_state *state);
extern int IMM_GetOneChannelValue(int dwChannel, int data[4], int* rawdata);
extern int IMM_GetOneChannelValue_Cali(int Channel, int *voltage);

static struct pinctrl *sec_battery_ctrl;
static struct pinctrl_state *sec_battery_enable;
static struct pinctrl_state *sec_battery_disable;


static bool get_charger_detect(void)
{
	return upmu_is_chr_det();
}

static int adc_read_vol(void)
{
#if 1
	int id_volt = 0;
	int ret = 0;
	int i;
	int sum = 0;
	
	for(i = 0; i < 10; i++)
	{
		ret = IMM_GetOneChannelValue_Cali(4, &id_volt);
		if(ret != 0)
			BATTERY_DEBUG("id_volt read fail\n");
		else
			BATTERY_DEBUG("id_volt read id_volt = %d\n", id_volt);		
		
		if(id_volt > 0)
		{
			sum += id_volt;
		}
		else
		{
			BATTERY_DEBUG("sec_battery_check() failed\n");
		}
	}

	ret = sum / 10;
	return ret;
#else
	int adc[1];
	int data[4] ={0,0,0,0};
	int sum = 0;
	int adc_vol=0;
	int num = 0;
	for(num=0;num<10;num++)
	{
		IMM_GetOneChannelValue(4, data, NULL);
		sum+=(data[0]*100+data[1]);
	}
	adc_vol = sum/10;

	BATTERY_DEBUG("second battery adc_vol is %d\n",adc_vol);

	return (adc_vol > 60) ? 0 : 1;
#endif
}


static void sec_battery_ctrl_onoff(int on)
{
	BATTERY_FUNC();
	if(on == 1)
	{
		if (!IS_ERR(sec_battery_enable))
			pinctrl_select_state(sec_battery_ctrl, sec_battery_enable);
	}
	else
	{
		if (!IS_ERR(sec_battery_disable))
			pinctrl_select_state(sec_battery_ctrl, sec_battery_disable);
	}
}

static bool sec_bat_full_check(void)	{
	int sec_bat_gpio_value = 0;
	bool is_full = 0;

	BATTERY_FUNC();

	sec_bat_gpio_value = gpio_get_value(sec_bat_gpio);
	BATTERY_DEBUG("sec_bat_gpio_value = %d\n", sec_bat_gpio_value);

	if(sec_bat_gpio_value) {
		is_full = 1;
	} else {
		is_full = 0;
	}

	return is_full;
}

void sec_battery_check(void)
{
	int val = 0;
	int val_tmp = 0;

	BATTERY_FUNC();

	if(get_charger_detect())
	{
		BATTERY_DEBUG("AC charger is exist, second batttery charge disable return !!\n");
		sec_battery_ctrl_onoff(0);
		sec_chargeing_on = 0;
		return;
	}

	val = adc_read_vol();
	BATTERY_DEBUG("charger enable  val = %d\n",val);
	val_tmp = val * 43 / 10;
	BATTERY_DEBUG("charger enable  val_tmp = %d\n",val_tmp);
	val = val_tmp;
	BATTERY_DEBUG("charger enable  val = %d\n",val);
	
	if((val < 4000000 && val > 0) && sec_chargeing_on == 0)
	{
		BATTERY_DEBUG("sec bat < 4v ,charger enable  val = %d\n",val);
		sec_battery_ctrl_onoff(1);
		sec_chargeing_on = 1;
	}
	else if((val >= 4200000 || sec_bat_full_check()) && sec_chargeing_on == 1)
	{
		sec_battery_ctrl_onoff(0);
		sec_chargeing_on = 0;
	}
}
EXPORT_SYMBOL(sec_battery_check);

void sec_battery_dts_init(struct platform_device *dev)
{
	int ret = 0;
	BATTERY_FUNC();

    sec_battery_ctrl = devm_pinctrl_get(&dev->dev);    
	if (IS_ERR(sec_battery_ctrl)) {
		ret = PTR_ERR(sec_battery_ctrl);
		pr_err("Cannot find sec_battery pinctrl!\n");
		return;
	}

	sec_battery_enable = pinctrl_lookup_state(sec_battery_ctrl, "sec_battery_enable");
	if (IS_ERR(sec_battery_enable)) {
		ret = PTR_ERR(sec_battery_enable);
		pr_err("Cannot find alsps sec_battery_enable pin_cfg!\n");
		return;
	}

	sec_battery_disable = pinctrl_lookup_state(sec_battery_ctrl, "sec_battery_disable");
	if (IS_ERR(sec_battery_disable)) {
		ret = PTR_ERR(sec_battery_disable);
		pr_err("Cannot find alsps sec_battery_disable pin_cfg!\n");
		return;
	}
}


static irqreturn_t sec_battery_eint_func(int irq, void *desc)
{
	int sec_bat_gpio_value = 0;
	BATTERY_FUNC();
	sec_bat_gpio_value = gpio_get_value(sec_bat_gpio);
	pr_err("sec_battery_eint_func sec_bat_gpio_value :%d sec_chargeing_on :%d\n",sec_bat_gpio_value, sec_chargeing_on); 

	disable_irq_nosync(sec_bat_irq);
	if(sec_bat_gpio_value == 0){
		irq_set_irq_type(sec_bat_irq, IRQ_TYPE_LEVEL_HIGH);
	} else {
		irq_set_irq_type(sec_bat_irq, IRQ_TYPE_LEVEL_LOW);
		if(sec_chargeing_on == 1) {
			sec_battery_ctrl_onoff(0);
			sec_chargeing_on = 0;
		}
	}
	enable_irq(sec_bat_irq);

	return IRQ_HANDLED;
}


static int sec_battery_setup_eint(void)
{
    int ints[2] = {0, 0};
    struct device_node *node_sec_bat;
	int sec_bat_gpio_value = 0;

	BATTERY_FUNC();

    node_sec_bat = of_find_compatible_node(NULL, NULL, "mediatek,eint_secbat");	
    if(node_sec_bat)
        pr_err("find irq node success!!\n");
    else
        pr_err("null irq node!!\n");

    if(node_sec_bat)
    {
		of_property_read_u32_array(node_sec_bat, "debounce", ints, ARRAY_SIZE(ints));
		pr_err("ptt_key ints[0] = %d, ints[1] = %d!!\n", ints[0], ints[1]);
		sec_bat_gpio = ints[0];

		gpio_request(sec_bat_gpio, "sec_bat_gpio");
		
    }else {
		pr_err("null irq node!!\n");
		return -EINVAL;
	}

}

static int sec_battery_probe(struct platform_device *dev)
{	
	BATTERY_FUNC();

	sec_battery_dts_init(dev);
	sec_battery_ctrl_onoff(0);
	sec_battery_setup_eint();

	return 0;
}

static int sec_battery_remove(struct platform_device *dev)
{
	BATTERY_FUNC();

	return 0;
}

static const struct of_device_id sec_battery_of_match[] = {
    { .compatible = "mediatek,sec_battery", },
    {},
};

const struct dev_pm_ops sec_battery_pm_ops = {
    .suspend = NULL,
    .resume = NULL,
};

static struct platform_driver sec_battery_driver = {
	.probe = sec_battery_probe,
    .shutdown = NULL,
	.remove = sec_battery_remove,
	.driver = {
        .owner	= THIS_MODULE,
		.name = "sec_battery",
        .pm = &sec_battery_pm_ops,
        .of_match_table = sec_battery_of_match,
	},
};

static int sec_battery_mod_init(void)
{
	BATTERY_FUNC();

	if(platform_driver_register(&sec_battery_driver) != 0)
	{
		BATTERY_DEBUG("unable to register sec_battery driver\n");
		return -1;
	}
	
	return 0;
}

static void sec_battery_mod_exit(void)
{
	BATTERY_FUNC();

	platform_driver_unregister(&sec_battery_driver);
}

module_init(sec_battery_mod_init);
module_exit(sec_battery_mod_exit);

MODULE_DESCRIPTION("Rinlink sec_battery driver");
MODULE_AUTHOR("AL <wuzhiyong@rinlink.com>");
MODULE_LICENSE("GPL");
