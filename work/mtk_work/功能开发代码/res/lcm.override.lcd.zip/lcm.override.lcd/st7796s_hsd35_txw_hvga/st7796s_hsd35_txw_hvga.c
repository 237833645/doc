/*****************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software is protected by Copyright and the information contained
 *  herein is confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of MediaTek Inc. (C) 2008
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 *  RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
 *  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
 *
 *****************************************************************************/

#if defined(BUILD_LK)
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#else
#include <linux/string.h>

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/i2c.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <mt-plat/mt_gpio.h>
#include <mach/gpio_const.h>
#include <linux/input.h>
#include <linux/printk.h>
#include <linux/proc_fs.h> //proc file use

#include "lt9211.h"
#include "isl97900.h"
#include "ovp0921.h"
#include "lcd_gpio.h"

#endif
#include "lcm_drv.h"


static int should_init_lt9211 = 1;

// ---------------------------------------------------------------------------
//  Local Constants
// ---------------------------------------------------------------------------

#define FRAME_WIDTH  (1280)
#define FRAME_HEIGHT (720)

#define REGFLAG_DELAY             							0xFE
#define REGFLAG_END_OF_TABLE      							0xFA    //0xFFF ??   // END OF REGISTERS MARKER

// ---------------------------------------------------------------------------
//  Local Variables
// ---------------------------------------------------------------------------

static LCM_UTIL_FUNCS lcm_util = {0};

#define SET_RESET_PIN(v)    (lcm_util.set_reset_pin((v)))

#define UDELAY(n) (lcm_util.udelay(n))
#if defined(BUILD_LK)
#define MDELAY(n)   mdelay(n)  // (lcm_util.mdelay(n*20000))
#else
extern void msleep(unsigned int msecs);
#define MDELAY(n)   msleep(n)  // (lcm_util.mdelay(n*20000))
#endif


// ---------------------------------------------------------------------------
//  Local Functions
// ---------------------------------------------------------------------------

#define dsi_set_cmdq_V2(cmd, count, ppara, force_update)	lcm_util.dsi_set_cmdq_V2(cmd, count, ppara, force_update)
#define dsi_set_cmdq(pdata, queue_size, force_update)		lcm_util.dsi_set_cmdq(pdata, queue_size, force_update)
#define wrtie_cmd(cmd)										lcm_util.dsi_write_cmd(cmd)
#define write_regs(addr, pdata, byte_nums)					lcm_util.dsi_write_regs(addr, pdata, byte_nums)
#define read_reg(cmd) lcm_util.dsi_dcs_read_lcm_reg(cmd)
#define read_reg_v2(cmd, buffer, buffer_size)   			lcm_util.dsi_dcs_read_lcm_reg_v2(cmd, buffer, buffer_size)

struct LCM_setting_table {
  unsigned cmd;
  unsigned char count;
  unsigned char para_list[64];
};



//static unsigned char temp_v = 0x12 ;
/*HSD*/
static struct LCM_setting_table lcm_initialization_setting[] = {
/* ST7701 Initial Code For IVO4.98TN(C050SWY7-0)                              */
{0x11, 0,{}},
{REGFLAG_DELAY,120,{}}, 
{0xf0, 1,{0xc3}},
{0xf0, 1,{0x96}},
{0x36, 1,{0x48}},
{0xb4, 1,{0x01}},
{0xe8, 8,{0x40,0x8a,0x00,0x00,0x29,0x19,0xa5,0x33}},
{0xc2, 1,{0xa7}},
{0xc5, 1,{0x32}},
{0xe0, 14,{0xf0,0x00,0x02,0x0a,0x0d,0x1d,0x35,0x55,0x45,0x3c,0x17,0x17,0x18,0x1b}},
{0xe1, 14,{0xf0,0x00,0x02,0x07,0x06,0x04,0x2e,0x44,0x45,0x0b,0x17,0x16,0x18,0x1b}},
{0xf0, 1,{0x3c}},
{0xf0, 1,{0x69}},
{0x3a, 1, {0x77}},

{0x11, 0,{}},
{REGFLAG_DELAY,120,{}}, 
{0x29, 0,{}},
{REGFLAG_DELAY,20,{}}, 
{REGFLAG_END_OF_TABLE, 0x00, {}}

};

static struct LCM_setting_table lcm_deep_sleep_mode_in_setting[] = {
  // Display off sequence
  {0x28, 1, {0x00}},
  {REGFLAG_DELAY, 20, {}},
  // Sleep Mode On
  {0x10, 1, {0x00}},
  {REGFLAG_DELAY, 120, {}},
  {REGFLAG_END_OF_TABLE, 0x00, {}}
};

static void push_table(struct LCM_setting_table *table, unsigned int count, unsigned char force_update)
{
  unsigned int i;

  for(i = 0; i < count; i++) {
    unsigned cmd;
    cmd = table[i].cmd;

    switch (cmd) {
      case REGFLAG_DELAY :
        MDELAY(table[i].count);
        break;

      case REGFLAG_END_OF_TABLE :
        break;

      default:
        dsi_set_cmdq_V2(cmd, table[i].count, table[i].para_list, force_update);
    }
  }
}


// ---------------------------------------------------------------------------
//  LCM Driver Implementations
// ---------------------------------------------------------------------------
static void lcm_set_util_funcs(const LCM_UTIL_FUNCS *util)
{
  memcpy(&lcm_util, util, sizeof(LCM_UTIL_FUNCS));
}

static void lcm_get_params(LCM_PARAMS *params)
{
    memset(params, 0, sizeof(LCM_PARAMS));

    params->type   = LCM_TYPE_DSI;

    params->width  = FRAME_WIDTH;
    params->height = FRAME_HEIGHT;


#if 0//(LCM_DSI_CMD_MODE)
    params->dsi.mode   = CMD_MODE;
#else
    params->dsi.mode   = SYNC_EVENT_VDO_MODE;
#endif
    // DSI
    /* Command mode setting */
    params->dsi.LANE_NUM				= LCM_TWO_LANE;

    //The following defined the fomat for data coming from LCD engine.
    params->dsi.data_format.color_order = LCM_COLOR_ORDER_RGB;
    params->dsi.data_format.trans_seq	= LCM_DSI_TRANS_SEQ_MSB_FIRST;
    params->dsi.data_format.padding 	= LCM_DSI_PADDING_ON_LSB;
    params->dsi.data_format.format	  = LCM_DSI_FORMAT_RGB888;

    // Video mode setting
    params->dsi.intermediat_buffer_num = 2;

    params->dsi.PS=LCM_PACKED_PS_24BIT_RGB888;

    params->dsi.word_count=FRAME_WIDTH*3;	//DSI CMD mode need set these two bellow params, different to 6577
    params->dsi.vertical_active_line=FRAME_HEIGHT;

    params->dsi.vertical_sync_active	= 3;// 3    2
    params->dsi.vertical_backporch		= 22;// 20   11
    params->dsi.vertical_frontporch		= 1; // 1  12 9
    params->dsi.vertical_active_line	= FRAME_HEIGHT;

    params->dsi.horizontal_sync_active	= 137;// 50  2
    params->dsi.horizontal_backporch	= 191;//150 20
    params->dsi.horizontal_frontporch	= 56;//150 20
    params->dsi.horizontal_active_pixel	= FRAME_WIDTH;

    params->dsi.PLL_CLOCK=447;//208;//160
   
}
static unsigned int lcm_compare_id(void);
static void lcm_init(void)
{
#ifdef BUILD_LK
	printf("\n\n wangfeng lk lcm_init() start \n\n");
#else
	printk("\n\n wangfeng kernel lcm_init() start \n\n");
#endif

#ifdef BUILD_LK
	gpio_lcd_init();
#endif


	gpio_lcd_powerup();
	MDELAY(20);

	push_table(lcm_initialization_setting, sizeof(lcm_initialization_setting) / sizeof(struct LCM_setting_table), 1);

#if 1
	//LT9211_RST();
	//MDELAY(20);
	//LT9211_MIPI_Pattern_Config();
	//LT9211_MIPI2MIPI_Config();

	OVP0921_RST(0);
	MDELAY(20);
	OVP0921_RST(1);	
	MDELAY(20);

	ISL_97900_RST();
	MDELAY(20);	
	DevISL97900_l_Init(0);
	isl97900_l_Write_Current(0,10);
	DevISL97900_r_Init(1);
	isl97900_r_Write_Current(1,10);	
#endif
#ifdef BUILD_LK
	printf("\n\n wangfeng lk lcm_init() end \n\n");
#else
	printk("\n\n wangfeng kernel lcm_init() end \n\n");
#endif


}

static void lcm_suspend(void)
{
#ifdef BUILD_LK
	printf("wangfeng lk lcm_suspend() start\n\n");
#else
	printk("wangfeng kernel lcm_suspend() start \n\n");
#endif

  	push_table(lcm_deep_sleep_mode_in_setting, sizeof(lcm_deep_sleep_mode_in_setting) / sizeof(struct LCM_setting_table), 1);

	LT9211_POWERDOWN();	
	gpio_lcd_powerdown();

#ifdef BUILD_LK
	printf("wangfeng lk lcm_suspend() end\n\n");
#else
	printk("wangfeng kernel lcm_suspend() end \n\n");
#endif
	should_init_lt9211 = 0;


}

static void lcm_resume(void)
{
#ifdef BUILD_LK
	printf("\n\n wangfeng lk lcm_resume() start \n\n");
#else
	printk("\n\n wangfeng kernel lcm_resume() start \n\n");
#endif

	lcm_init();
	should_init_lt9211 = 1;

#ifdef BUILD_LK
	printf("\n\n wangfeng lk lcm_resume() end \n\n"); 
#else
	printk("\n\n wangfeng kernel lcm_resume() end \n\n"); 
#endif
}


extern int IMM_GetOneChannelValue(int dwChannel, int data[4], int* rawdata);
static int adc_read_vol(void)
{
	int adc[1];
	int data[4] ={0,0,0,0};
	int sum = 0;
	int adc_vol=0;
	int num = 0;

	for(num=0;num<10;num++)
	{
		IMM_GetOneChannelValue(12, data, adc);
		sum+=(data[0]*100+data[1]);
	}
	adc_vol = sum/10;

#if defined(BUILD_LK)
	printf("st7796s  adc_vol is %d\n",adc_vol);
#else
	printk("st7796s  adc_vol is %d\n",adc_vol);
#endif

	return (adc_vol>90) ? 0 : 1;
}




static unsigned int lcm_compare_id(void)
{
	unsigned int array[1];
	unsigned short device_id;
	unsigned char buffer[4];

	return 1;
			
	SET_RESET_PIN(1);
	MDELAY(10);
	SET_RESET_PIN(0);
	MDELAY(20);
	SET_RESET_PIN(1);
	MDELAY(20);	
	

	array[0] = 0x00043700;
	dsi_set_cmdq(array, 1, 1);
	MDELAY(10); 
	
	read_reg_v2(0xd3, buffer, 4);	
	device_id = ((buffer[1]<<8)|(buffer[2])) + adc_read_vol();
	
#if defined(BUILD_LK)
	printf("st7796s %s,line=%d, id = 0x%x, buffer[0]=0x%08x,buffer[1]=0x%08x\n",__func__,__LINE__, device_id, buffer[0],buffer[1]);
#else
	printk("st7796s %s,line=%d, id = 0x%x, buffer[0]=0x%08x,buffer[1]=0x%08x\n",__func__,__LINE__, device_id, buffer[0],buffer[1]);
#endif
    return ((0x7797 == device_id) ? 1:0);

}

static void lcm_setbacklight(unsigned int level)
{
#if defined(BUILD_LK)
		printf("st7796s %s,line=%d , level = %d, should_init_lt9211 = %d\n",__func__,__LINE__, level, should_init_lt9211);
#else
		printk("st7796s %s,line=%d , level = %d, should_init_lt9211 = %d\n",__func__,__LINE__, level, should_init_lt9211);
#endif

	if(level && should_init_lt9211) {
		LT9211_RST();
		MDELAY(20);
		//LT9211_MIPI_Pattern_Config();
		LT9211_MIPI2MIPI_Config();
		should_init_lt9211 = 0;
	}
#if defined(BUILD_LK)
		printf("st7796s %s,line=%d , level = %d, should_init_lt9211 = %d\n",__func__,__LINE__, level, should_init_lt9211);
#else
		printk("st7796s %s,line=%d , level = %d, should_init_lt9211 = %d\n",__func__,__LINE__, level, should_init_lt9211);
#endif

}



// ---------------------------------------------------------------------------
//  Get LCM Driver Hooks
// ---------------------------------------------------------------------------
LCM_DRIVER st7796s_hsd35_txw_hvga_lcm_drv=
{
  .name			= "st7796s_hsd35_txw_hvga",
  .set_util_funcs = lcm_set_util_funcs,
  .get_params     = lcm_get_params,
  .init           = lcm_init,
  .suspend        = lcm_suspend,
  .resume         = lcm_resume,
  .compare_id    = lcm_compare_id,
  .set_backlight = lcm_setbacklight,
};
