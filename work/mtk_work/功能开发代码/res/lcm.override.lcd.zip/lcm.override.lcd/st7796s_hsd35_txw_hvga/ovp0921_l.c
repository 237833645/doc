#include "ovp0921.h"

#ifdef BUILD_LK

#define OVP0921_L_SLAVE_ADDR  0x05
struct mt_i2c_t ovp0921_l_i2c;

/* ---------------------------------------------------------------------------------------------------------------------------------*/
u32 ovp0921_l_write_byte(u8 addr, u8 value)
{
    u32 ret_code = I2C_OK;
    u8 write_data[2];
    u8 len;

    write_data[0] = addr;
    write_data[1] = value;

    ovp0921_l_i2c.id = 1; /* I2C0; */
    ovp0921_l_i2c.addr = (OVP0921_L_SLAVE_ADDR);
    ovp0921_l_i2c.mode = ST_MODE;
    ovp0921_l_i2c.speed = 100;
    len = 2;

    ret_code = i2c_write(&ovp0921_l_i2c, write_data, len);
	if(I2C_OK != ret_code)
	    OVP0921_DBG("%s: ovp0921_l_write_byte error: ret_code: %d\n", __func__, ret_code); 

    return ret_code;
}
u32 ovp0921_l_read_byte(u8 addr, u8 *dataBuffer)
{
	u32 ret_code = I2C_OK;
    kal_uint8 read_data[2];
    u32 len;
    *dataBuffer = addr,

    ovp0921_l_i2c.id = 1; /* I2C0; */
    ovp0921_l_i2c.addr = (OVP0921_L_SLAVE_ADDR);
    ovp0921_l_i2c.mode = ST_MODE;
    ovp0921_l_i2c.speed = 100;
    len = 1;

	ret_code = i2c_write_read(&ovp0921_l_i2c, dataBuffer, len, len);
	if(I2C_OK != ret_code)
		OVP0921_DBG("%s: ovp0921_l_read_byte lk error: ret_code: %d,ic:0x%x\n", __func__, ret_code,read_data[0]); 

    return ret_code;
}
#else

#define I2C_OVP0921_L_ID_NAME "ovp0921_l"
static const struct of_device_id ovp0921_l_of_match[] = {
    {.compatible = "mediatek,ovp0921_l"},
    {},
};
	
static struct i2c_client *ovp0921_l_i2c_client;
static DEFINE_MUTEX(ovp0921_l_i2c_access);
static int ovp0921_l_probe(struct i2c_client *client, const struct i2c_device_id *id);
static int ovp0921_l_remove(struct i2c_client *client);

struct ovp0921_l_dev {
    struct i2c_client *client;
};

static const struct i2c_device_id ovp0921_l_id[] = {
    {I2C_OVP0921_L_ID_NAME, 0},
    {}
};


static struct i2c_driver ovp0921_l_iic_driver = {
    .id_table = ovp0921_l_id,
    .probe = ovp0921_l_probe,
    .remove = ovp0921_l_remove,
    .driver = {
        .owner = THIS_MODULE,
        .name = "ovp0921_l",
        .of_match_table = ovp0921_l_of_match,
    },
};
		

static int i2c_write_byte(struct i2c_client *client, u8 reg, u8 val)
{
	int rc = 0;
	u8 txbuf[512] = {0};

	if(!client)
	{
		//OVP0921_DBG("%s i2c_write_byte-> client == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = {
		{
		.addr = client->addr,
		.flags = 0,
		.len = 2,
		.buf = txbuf,
		},
	};

	txbuf[0] = reg;
	txbuf[1] = val;
	
	rc = i2c_transfer(client->adapter, msg, 1);
	if(rc < 0)
	{
		OVP0921_DBG("%s i2c_transfer i2c write error rc= 0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	OVP0921_DBG("%s ovp0921_l success rc= 0d[%d]\n", __func__, rc);

	return rc;
}

static int i2c_read_byte(struct i2c_client *client, u8 reg, char *buf, u32 size)
{
	int rc = 0;
	u8 rxbuf[512] = {0};

	if(!client || !buf)
	{
		//OVP0921_DBG("%s i2c_write_byte-> client == null || buf == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = 
	{
		{
			.addr = client->addr,
			.flags = 0,
			.len = 1,
			.buf = rxbuf,
		},
		{
			.addr = client->addr,
			.flags = I2C_M_RD,
			.len = 1,
			.buf = rxbuf,
		},
	};

	rxbuf[0] = reg;
	
	OVP0921_DBG("%s addr = %x \n", __func__, client->addr);
	rc = i2c_transfer(client->adapter, msg, 2);
	if(rc < 0)
	{
		OVP0921_DBG("%s i2c_transfer error rc=0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	*buf = rxbuf[0];
	OVP0921_DBG("%s ovp0921_l success rc=0d[%d], rxbuf[0] = 0x%x, *buf = 0x%x\n", __func__, rc, rxbuf[0], *buf);

	return rc;
}

int ovp0921_l_write_bytes(unsigned char cmd, unsigned char writeData)
{
	int ret = 0;
	if(ovp0921_l_i2c_client == NULL)
	{
		OVP0921_DBG("ovp0921_l_write_bytes ovp0921_l_i2c_client == NULL !!\n");
		return -1;
	}
	mutex_lock(&ovp0921_l_i2c_access);

	ret = i2c_write_byte(ovp0921_l_i2c_client, cmd, writeData);
	if (ret < 0)
	{
		mutex_unlock(&ovp0921_l_i2c_access);
		OVP0921_DBG("ovp0921_l_write_bytes i2c_master_send fail ret= 0d%d!!\n", ret);
		
		return ret;
	}
	mutex_unlock(&ovp0921_l_i2c_access);
	OVP0921_DBG("%s success end ret=0d%d \n", __func__, ret);
	
	return ret;
}
EXPORT_SYMBOL(ovp0921_l_write_bytes);

int ovp0921_l_read_bytes(unsigned char cmd, unsigned char *returnData)
{
	int ret = 0;	
	char readData = 0;
	if(ovp0921_l_i2c_client == NULL) 
	{
	   OVP0921_DBG(" ovp0921_l_read_bytes ovp0921_l_i2c_client == NULL \n");
	   return -1;
	}
	mutex_lock(&ovp0921_l_i2c_access);	
	ret = i2c_read_byte(ovp0921_l_i2c_client, cmd, &readData, 1);
	if (ret < 0) {
		mutex_unlock(&ovp0921_l_i2c_access);
		OVP0921_DBG(" ovp0921_l_read_bytes i2c_master_recv error ret = 0d%d\n", ret);
		return ret;
	}
	*returnData = readData;	

	mutex_unlock(&ovp0921_l_i2c_access);
	OVP0921_DBG("%s success end ret=0d%d readData=0x%x\n", __func__, ret, readData);

    return ret;
}
EXPORT_SYMBOL(ovp0921_l_read_bytes);


static int ovp0921_l_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    OVP0921_DBG("ovp0921_l_iic_probe\n");
    OVP0921_DBG("%s ==>name=%s addr=0x%x\n", __func__, client->name, client->addr);
    ovp0921_l_i2c_client = client;
    return 0;
}
static int ovp0921_l_remove(struct i2c_client *client)
{
    OVP0921_DBG("ovp0921_l_remove\n");
    ovp0921_l_i2c_client = NULL;
    i2c_unregister_device(client);
    return 0;
}


static int __init ovp0921_l_i2c_init(void)
{
    OVP0921_DBG("ovp0921_l_iic_init\n");

    i2c_add_driver(&ovp0921_l_iic_driver);

    OVP0921_DBG("ovp0921_l_iic_init success\n");
    return 0;
}
static void __exit ovp0921_l_i2c_exit(void)
{
    OVP0921_DBG("ovp0921_l_iic_exit\n");
    i2c_del_driver(&ovp0921_l_iic_driver);

}
module_init(ovp0921_l_i2c_init);
module_exit(ovp0921_l_i2c_exit);
MODULE_AUTHOR("Xiaokuan Shi");
MODULE_DESCRIPTION("MTK ovp0921_l I2C Driver");

#endif

int ovp0921_l_suspend(int ch)
{
	int ret = 0;
	return ret;	
}

int ovp0921_l_resume(int ch)
{
	int ret = 0;
	return ret;	
}


int ovp0921_l_init(int ch)
{
	int ret = 0;
#ifdef BUILD_LK

#endif
	return ret;
}
