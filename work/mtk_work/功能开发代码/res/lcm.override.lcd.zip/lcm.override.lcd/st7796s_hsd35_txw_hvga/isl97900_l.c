
#include "isl97900.h"



ISL_TypeDef Isl97900_l_DefReg[] = 
{
	{0x00, 0x00},
	{0x01, 0x01},
	{0x02, 0x04},
	{0x03, 0x00},
	{0x04, 0x82},
	{0x05, 0x10},
	{0x06, 0x00},
	{0x07, 0x00},
	{0x08, 0x00},
	{0x09, 0x00},
	{0x0A, 0x00},
	{0x0B, 0x00},
	{0x0C, 0x00},
	{0x0D, 0x00},
	{0x0E, 0x00},
	{0x0F, 0x00},
	{0x10, 0x00},
	{0x11, 0x00},
	{0x12, 0x00},
	{0x13, 0x20},
	{0x14, 0x20},
	{0x15, 0x20},
	{0x16, 0x00},
	{0x17, 0x00},
	{0x18, 0x66},
	{0x19, 0x9a},
	{0x1A, 0x9a},
	{0x1B, 0x9a},
	{0x1C, 0x9a},
	{0x1D, 0x55},
	{0x1E, 0x40},
};

ISL_Current Isl97900_l_GainDAC[] = 
{
	{0x10, 0x10, 0x10, 0x00},	//23.46mA	//00
	{0x18, 0x18, 0x18, 0x00},	//35.19mA	//01
	{0x20, 0x20, 0x20, 0x00},	//46.92mA	//02
	{0x28, 0x28, 0x28, 0x00},	//58.65mA	//03
	{0x30, 0x30, 0x30, 0x00},	//70.38mA	//04
	{0x38, 0x38, 0x38, 0x00},	//82.10mA	//05
	{0x40, 0x40, 0x40, 0x00},	//93.84mA	//06
	{0x48, 0x48, 0x48, 0x00},	//105.57mA	//07
	{0x50, 0x50, 0x50, 0x00},	//117.30mA	//08
	{0x58, 0x58, 0x58, 0x00},	//129.03mA	//09
	{0x60, 0x60, 0x60, 0x00},	//140.76mA	//10
	{0x68, 0x68, 0x68, 0x00},	//152.49mA	//11
	{0x70, 0x70, 0x70, 0x00},	//164.22mA	//12
	{0x78, 0x78, 0x78, 0x00},	//175.95mA	//13
	{0x80, 0x80, 0x80, 0x00},	//187.68mA	//14
	{0x88, 0x88, 0x88, 0x00},	//199.41mA	//15
	{0x90, 0x90, 0x90, 0x00},	//211.14mA	//16
	{0x98, 0x98, 0x98, 0x00},	//222.87mA	//17
	{0xA0, 0xA0, 0xA0, 0x00},	//234.60mA	//18
	{0xA8, 0xA8, 0xA8, 0x00},	//246.33mA	//19
	{0xB0, 0xB0, 0xB0, 0x00},	//258.06mA	//20
	{0xB8, 0xB8, 0xB8, 0x00},	//269.79mA	//21
	{0xC0, 0xC0, 0xC0, 0x00},	//281.52mA	//22
	{0xC8, 0xC8, 0xC8, 0x00},	//293.25mA	//23
	{0xD0, 0xD0, 0xD0, 0x00},	//304.98mA	//24
	{0xD8, 0xD8, 0xD8, 0x00},	//316.71mA	//25
	{0xE0, 0xE0, 0xE0, 0x00},	//328.44mA	//26
};

											
BOOLEAN_TypeDef isl97900_l_Read(uint8_t ch, uint8_t Addr, uint8_t *pData, uint16_t len)
{
	BOOLEAN_TypeDef rtn = FALSE;
	unsigned char readbuf = 0;

	if( Addr > 0x29 ) return FALSE;
	switch(ch)
	{
		case 0:
#if defined(BUILD_LK)
			rtn = isl97900_l_read_byte(Addr, &readbuf);
#else	
			rtn = isl97900_l_read_bytes(Addr, &readbuf);
#endif
			if(rtn < 0)
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_read_byte lk error\n", __func__, __LINE__);
#else			
				printk("%s %d isl97900_l_read_bytes kernel error\n", __func__, __LINE__);
#endif
			}
			else
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_read_byte lk pass %x = %x\n", __func__, __LINE__, Addr, readbuf);
#else			
				printk("%s %d isl97900_l_read_bytes kernel pass %x = %x\n", __func__, __LINE__, Addr, readbuf);
#endif				
				rtn = TRUE;
			}
		break;
		case 1:
#if defined(BUILD_LK)
			rtn = isl97900_l_read_byte(Addr, &readbuf);
#else			
			rtn = isl97900_l_read_bytes(Addr, &readbuf);			
#endif
			if(rtn < 0)
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_read_byte lk error\n", __func__, __LINE__);
#else			
				printk("%s %d isl97900_l_read_bytes kernel error\n", __func__, __LINE__);
#endif
			}
			else
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_read_byte lk pass %x = %x\n", __func__, __LINE__,Addr,  readbuf);
#else			
				printk("%s %d isl97900_l_read_bytes kernel pass %x = %x\n", __func__, __LINE__,Addr,  readbuf);
#endif						
				rtn = TRUE;
			}		
		break;
		default:
		break;
	}

	*pData = readbuf;

	return rtn;
}


BOOLEAN_TypeDef isl97900_l_Write(uint8_t ch, uint8_t Addr, uint8_t *pData, uint16_t len)
{
	BOOLEAN_TypeDef rtn = FALSE;
	unsigned char writebuf = 0;

	if( Addr > 0x1E ) return FALSE;

	switch(ch)
	{
		case 0:
			writebuf = *pData;
#if defined(BUILD_LK)
			rtn = isl97900_l_write_byte(Addr, writebuf);
#else			
			rtn = isl97900_l_write_bytes(Addr, writebuf);
#endif
			if(rtn < 0)
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_write_bytes lk error\n", __func__, __LINE__);
#else			
				printk("%s %d isl97900_l_write_bytes kernel error\n", __func__, __LINE__);
#endif
			}
			else
			{
				rtn = TRUE;
			}			
		break;
		case 1:
			writebuf = *pData;
#if defined(BUILD_LK)
			rtn = isl97900_l_write_byte(Addr, writebuf);
#else			
			rtn = isl97900_l_write_bytes(Addr, writebuf);
#endif
			if(rtn < 0)
			{
#if defined(BUILD_LK)
				printf("%s %d isl97900_l_write_bytes lk error\n", __func__, __LINE__);
#else			
				printk("%s %d isl97900_l_write_bytes kernel error\n", __func__, __LINE__);
#endif
			}
			else
			{
				rtn = TRUE;
			}			
		break;
		default:
		break;
	}
	return rtn;
}

BOOLEAN_TypeDef isl97900_l_Write_Current(uint8_t ch, uint8_t vol)
{
	BOOLEAN_TypeDef rtn = FALSE;
	uint8_t tmp[3] = {0};
	uint8_t pData = 0;

	tmp[0] = (uint8_t)((Isl97900_l_GainDAC[vol].RedLEDLSB * 98) / 100);
	tmp[1] = (uint8_t)((Isl97900_l_GainDAC[vol].GreenLEDLSB * 1) / 1);
	tmp[2] = (uint8_t)((Isl97900_l_GainDAC[vol].BlueLEDLSB * 1) / 1);

	isl97900_l_Write(ch, CURRENT_REDLSB_REG, &tmp[0], 1);
	isl97900_l_Write(ch, CURRENT_GREENLSB_REG, &tmp[1], 1);
	isl97900_l_Write(ch, CURRENT_BLUELSB_REG, &tmp[2], 1);
	isl97900_l_Write(ch, CURRENT_RGBMSB_REG, &Isl97900_l_GainDAC[vol].RGBLEDMSB, 1);

	
	isl97900_l_Read(ch, CURRENT_REDLSB_REG, &pData, 1);
	
#if defined(BUILD_LK)
	printf("%s %d  lk read CURRENT_REDLSB_REG = %x \n", __func__, __LINE__, pData);
#else
	printk("%s %d  kernel read CURRENT_REDLSB_REG = %x \n", __func__, __LINE__, pData);
#endif
	
	return rtn;
}


/////////////////////////////////////////////////////////////////////////////////////
// ??	??:
// ??	??:
// ????????:	2018-04-03
// ????????: isl97900?????
// ?? ?? ??: liuqh
// ???????:
// ?????:
/////////////////////////////////////////////////////////////////////////////////////
BOOLEAN_TypeDef DevISL97900_l_Init(uint8_t ch)
{
	uint8_t tmp = 0;
	uint8_t i = 0;	
	BOOLEAN_TypeDef rtn = FALSE;

#if defined(BUILD_LK)
	printf("DevISL97900_l_Init lk start [%d]\n", ch);
#else	
	printk("DevISL97900_l_Init kernel start [%d]\n", ch);
#endif

	rtn = isl97900_l_Read( ch, 0x20, &tmp, 1 );
	if( rtn == TRUE )
	{
		for( i = 0; i < (sizeof(Isl97900_l_DefReg) / sizeof(ISL_TypeDef)); i++ )
		{
			isl97900_l_Write(ch, Isl97900_l_DefReg[i].Addr, &Isl97900_l_DefReg[i].Data, 1);
		}
	}
	else
	{
#if defined(BUILD_LK)
		printf("DevISL97900_l_Init lk failed \n");
#else	
		printk("DevISL97900_l_Init kernel failed \n");
#endif
	}

#if defined(BUILD_LK)
		printf("DevISL97900_l_Init lk end [%d],read 0x20 = [%x]\n", ch, tmp);
#else	
		printk("DevISL97900_l_Init kernel end [%d],read 0x20 = [%x]\n", ch, tmp);
#endif

	return rtn;
}

#ifdef BUILD_LK //lk i2c define
#define ISL97900_L_SLAVE_ADDR  0x29
struct mt_i2c_t isl97900_l_i2c;

/* ---------------------------------------------------------------------------------------------------------------------------------*/
uint32_t isl97900_l_write_byte(uint8_t addr, uint8_t value)
{
    uint32_t ret_code = 0;
    uint8_t write_data[2];
    uint16_t len;

    write_data[0] = addr;
    write_data[1] = value;

    isl97900_l_i2c.id = 1; /* I2C0; */
    isl97900_l_i2c.addr = (ISL97900_L_SLAVE_ADDR);
    isl97900_l_i2c.mode = ST_MODE;
    isl97900_l_i2c.speed = 100;
    len = 2;

    ret_code = i2c_write(&isl97900_l_i2c, write_data, len);
	if(ret_code < 0)
	    printf("%s: isl97900_l_write_byte error: ret_code: %d\n", __func__, ret_code); 

	//printf("%s:  lk success : ret_code: %d\n", __func__, ret_code);
	
    return ret_code;
}
uint32_t isl97900_l_read_byte(uint8_t addr, uint8_t *dataBuffer)
{
	uint32_t ret_code = 0;
    uint8_t read_data;
    uint16_t len;
	
    *dataBuffer = addr;

    isl97900_l_i2c.id = 1; /* I2C0; */
    isl97900_l_i2c.addr = (ISL97900_L_SLAVE_ADDR);
    isl97900_l_i2c.mode = ST_MODE;
    isl97900_l_i2c.speed = 100;
	isl97900_l_i2c.st_rs = I2C_TRANS_REPEATED_START;
    len = 1;

	ret_code = i2c_write_read(&isl97900_l_i2c, dataBuffer, len, len);
	if(ret_code < 0)
		printf("%s: lk error: ret_code: %d,ic:0x%x\n", __func__, ret_code,read_data); 


	//printf("%s: lk success: ret_code: %d, dataBuffer = %x\n", __func__, ret_code, *dataBuffer); 

    return ret_code;
}

#else
#define I2C_ISL97900_L_ID_NAME "isl97900_l"
static const struct of_device_id isl97900_l_of_match[] = {
    {.compatible = "mediatek,ISL97900CRZ_L"},
    {},
};
	
static struct i2c_client *isl97900_l_i2c_client;
static DEFINE_MUTEX(isl97900_l_i2c_access);
static int isl97900_l_probe(struct i2c_client *client, const struct i2c_device_id *id);
static int isl97900_l_remove(struct i2c_client *client);

struct isl97900_l_dev {
    struct i2c_client *client;
};

static const struct i2c_device_id isl97900_l_id[] = {
    {I2C_ISL97900_L_ID_NAME, 0},
    {}
};


static struct i2c_driver isl97900_l_iic_driver = {
    .id_table = isl97900_l_id,
    .probe = isl97900_l_probe,
    .remove = isl97900_l_remove,
    .driver = {
        .owner = THIS_MODULE,
        .name = "isl97900_l",
        .of_match_table = isl97900_l_of_match,
    },
};
		

static int i2c_write_byte(struct i2c_client *client, uint8_t reg, uint8_t val)
{
	int rc = 0;
	uint8_t txbuf[512] = {0};

	if(!client)
	{
		//printk("%s i2c_write_byte-> client == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = {
		{
		.addr = client->addr,
		.flags = 0,
		.len = 2,
		.buf = txbuf,
		},
	};

	txbuf[0] = reg;
	txbuf[1] = val;
	
	rc = i2c_transfer(client->adapter, msg, 1);
	if(rc < 0)
	{
		printk("%s i2c_transfer i2c write error rc= 0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	//printk("%s isl97900_l success rc= 0d[%d]\n", __func__, rc);

	return rc;
}

static int i2c_read_byte(struct i2c_client *client, uint8_t reg, char *buf, uint32_t size)
{
	int rc = 0;
	uint8_t rxbuf[512] = {0};

	if(!client || !buf)
	{
		//printk("%s i2c_write_byte-> client == null || buf == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = 
	{
		{
			.addr = client->addr,
			.flags = 0,
			.len = 1,
			.buf = rxbuf,
		},
		{
			.addr = client->addr,
			.flags = I2C_M_RD,
			.len = 1,
			.buf = rxbuf,
		},
	};

	rxbuf[0] = reg;
	
	//printk("%s addr = %x \n", __func__, client->addr);
	rc = i2c_transfer(client->adapter, msg, 2);
	if(rc < 0)
	{
		printk("%s i2c_transfer error rc=0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	*buf = rxbuf[0];
	//printk("%s isl97900_l success rc=0d[%d], rxbuf[0] = 0x%x, *buf = 0x%x\n", __func__, rc, rxbuf[0], *buf);

	return rc;
}

int isl97900_l_write_bytes(uint8_t cmd, uint8_t writeData)
{
	int ret = 0;
	if(isl97900_l_i2c_client == NULL)
	{
		printk("isl97900_l_write_bytes isl97900_l_i2c_client == NULL !!\n");
		return -1;
	}
	mutex_lock(&isl97900_l_i2c_access);

	ret = i2c_write_byte(isl97900_l_i2c_client, cmd, writeData);
	if (ret < 0)
	{
		mutex_unlock(&isl97900_l_i2c_access);
		printk("isl97900_l_write_bytes i2c_master_send fail ret= 0d%d!!\n", ret);
		
		return ret;
	}
	mutex_unlock(&isl97900_l_i2c_access);
	printk("%s success end ret=0d%d \n", __func__, ret);
	
	return ret;
}
EXPORT_SYMBOL(isl97900_l_write_bytes);

int isl97900_l_read_bytes(uint8_t cmd, uint8_t *returnData)
{
	int ret = 0;	
	uint8_t readData = 0;
	if(isl97900_l_i2c_client == NULL) 
	{
	   printk(" isl97900_l_read_bytes isl97900_l_i2c_client == NULL \n");
	   return -1;
	}
	mutex_lock(&isl97900_l_i2c_access);	
	ret = i2c_read_byte(isl97900_l_i2c_client, cmd, &readData, 1);
	if (ret < 0) {
		mutex_unlock(&isl97900_l_i2c_access);
		printk(" isl97900_l_read_bytes i2c_master_recv error ret=0d%d\n", ret);
		return ret;
	}
	*returnData = readData;	

	mutex_unlock(&isl97900_l_i2c_access);
	//printk("%s success end ret=0d%d readData=0x%x\n", __func__, ret, readData);

    return ret;
}
EXPORT_SYMBOL(isl97900_l_read_bytes);


static int isl97900_l_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    printk("isl97900_l_iic_probe\n");
    printk("%s ==>name=%s addr=0x%x\n", __func__, client->name, client->addr);
    isl97900_l_i2c_client = client;
    return 0;
}
static int isl97900_l_remove(struct i2c_client *client)
{
    printk("isl97900_l_remove\n");
    isl97900_l_i2c_client = NULL;
    i2c_unregister_device(client);
    return 0;
}


static int __init isl97900_l_init(void)
{
    printk("isl97900_l_init\n");

    i2c_add_driver(&isl97900_l_iic_driver);

    printk("isl97900_l_iic_init success\n");
    return 0;
}
static void __exit isl97900_l_exit(void)
{
    printk("isl97900_l_exit\n");
    i2c_del_driver(&isl97900_l_iic_driver);

}
module_init(isl97900_l_init);
module_exit(isl97900_l_exit);
MODULE_AUTHOR("Xiaokuan Shi");
MODULE_DESCRIPTION("MTK isl97900_l I2C Driver");
#endif
