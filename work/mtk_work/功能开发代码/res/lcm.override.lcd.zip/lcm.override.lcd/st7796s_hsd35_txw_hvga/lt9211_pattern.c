/******************************************************************************
  * @project: LT9211
  * @file: lt9211.c
  * @author: zll
  * @company: LONTIUM COPYRIGHT and CONFIDENTIAL
  * @date: 2019.12.16
/******************************************************************************/
#if defined(BUILD_LK)
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#else
#include <linux/string.h>

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/i2c.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <mt-plat/mt_gpio.h>
#include <mach/gpio_const.h>
#include <linux/input.h>
#include <linux/printk.h>
#include <linux/proc_fs.h> //proc file use
#endif

#include	"lt9211.h"

//struct video_timing video;
struct video_timing *pVideo_Format;

//hfp, hs, hbp, hact, htotal, vfp, vs, vbp, vact, vtotal, pixclk
struct video_timing video_640x480_60Hz     ={ 8, 96,  40, 640,   800, 33,  2,  10, 480,   525,  25000};
struct video_timing video_720x480_60Hz     ={16, 62,  60, 720,   858,  9,  6,  30, 480,   525,  27000};
struct video_timing video_1280x720_60Hz    ={110,40, 220,1280,  1650,  5,  5,  20, 720,   750,  74250};
struct video_timing video_1280x720_30Hz    ={110,40, 220,1280,  1650,  5,  5,  20, 720,   750,  37125};
struct video_timing video_1366x768_60Hz    ={26, 110,110,1366,  1592,  13, 6,  13, 768,   800,  81000};
struct video_timing video_1920x720_60Hz    ={148,44, 88, 1920,  2200, 28,  5,  12, 720,   765,  88000};
struct video_timing video_1920x1080_30Hz   ={88, 44, 148,1920,  2200,  4,  5,  36, 1080, 1125,  74250};
struct video_timing video_1920x1080_60Hz   ={88, 44, 148,1920,  2200,  4,  5,  36, 1080, 1125, 148500};
struct video_timing video_1920x1200_60Hz   ={48, 32,  80,1920,  2080,  3,  6,  26, 1200, 1235, 154000};
struct video_timing video_3840x2160_30Hz   ={176,88, 296,3840,  4400,  8,  10, 72, 2160, 2250, 297000};


u32 HDMI_WriteI2C_Byte(u8 RegAddr, u8 d)
{
	u32 flag = 0;
	//u8  data = d;
	
#if defined(BUILD_LK)
	flag=lt9211_write_byte(RegAddr, d);	
#else
	flag=lt9211_write_bytes(RegAddr, d);	
#endif
	return flag;
}

u8 HDMI_ReadI2C_Byte(u8 RegAddr)
{
	u8 ret = 0;
	u8  p_data=0;

#if defined(BUILD_LK)
	ret = lt9211_read_byte(RegAddr, &p_data);
	if(ret < 0)
	{
		printf("lt9211_read_byte lk error \n");
		return -1;
	}
	else
	{
		printf("HDMI_ReadI2C_Byte addr = %x,p_data = %x \n",RegAddr,p_data);
		return p_data;
	}
#else
	ret = lt9211_read_bytes(RegAddr, &p_data);
	if(ret < 0)
	{
		printk("HDMI_ReadI2C_Byte kernel error ret =   %d\n", ret);
		return -1;	
		
	}
	else
	{
		return p_data;
	}
#endif
}

void LT9211_ChipID(void)
{
    HDMI_WriteI2C_Byte(0xff,0x81);//register bank
    LT9211_DBG("LT9211 %s, %d Chip ID:%x \n",__func__, __LINE__,HDMI_ReadI2C_Byte(0x00));
    LT9211_DBG("LT9211 %s, %d %x, \n",__func__, __LINE__, HDMI_ReadI2C_Byte(0x01));
    LT9211_DBG("LT9211 %s, %d %x, \n",__func__, __LINE__, HDMI_ReadI2C_Byte(0x02));
}

void LT9211_SystemInt(void)
{
    /* system clock init */		   
    HDMI_WriteI2C_Byte(0xff,0x82);
    HDMI_WriteI2C_Byte(0x01,0x18);
    
    HDMI_WriteI2C_Byte(0xff,0x86);
    HDMI_WriteI2C_Byte(0x06,0x61); 	
    HDMI_WriteI2C_Byte(0x07,0xa8); //fm for sys_clk
    
    HDMI_WriteI2C_Byte(0xff,0x87); //��ʼ�� txpll �Ĵ����б�Ĭ��ֵ������
    HDMI_WriteI2C_Byte(0x14,0x08); //default value
    HDMI_WriteI2C_Byte(0x15,0x00); //default value
    HDMI_WriteI2C_Byte(0x18,0x0f);
    HDMI_WriteI2C_Byte(0x22,0x08); //default value
    HDMI_WriteI2C_Byte(0x23,0x00); //default value
    HDMI_WriteI2C_Byte(0x26,0x0f); 
}

/******************************************************************
*Founction: ���� Pattern	�����
*���ݽṹ��Video �е�timing������Video �� pixel clk��
*******************************************************************/
void LT9211_Patten(struct video_timing *video_format)
{
    u32 pclk_khz;
    u8 dessc_pll_post_div;
    u32 pcr_m, pcr_k;

    pclk_khz = video_format->pclk_khz;     

    HDMI_WriteI2C_Byte(0xff,0xf9);
	HDMI_WriteI2C_Byte(0x3e,0x80);  

    HDMI_WriteI2C_Byte(0xff,0x85);
	HDMI_WriteI2C_Byte(0x88,0xd0);  

    HDMI_WriteI2C_Byte(0xa1,0x77); 
    HDMI_WriteI2C_Byte(0xa2,0xff); 

	HDMI_WriteI2C_Byte(0xa3,(u8)((video_format->hs+video_format->hbp)/256));
	HDMI_WriteI2C_Byte(0xa4,(u8)((video_format->hs+video_format->hbp)%256));//h_start

	HDMI_WriteI2C_Byte(0xa5,(u8)((video_format->vs+video_format->vbp)%256));//v_start

   	HDMI_WriteI2C_Byte(0xa6,(u8)(video_format->hact/256));
	HDMI_WriteI2C_Byte(0xa7,(u8)(video_format->hact%256)); //hactive

	HDMI_WriteI2C_Byte(0xa8,(u8)(video_format->vact/256));
	HDMI_WriteI2C_Byte(0xa9,(u8)(video_format->vact%256));  //vactive

   	HDMI_WriteI2C_Byte(0xaa,(u8)(video_format->htotal/256));
	HDMI_WriteI2C_Byte(0xab,(u8)(video_format->htotal%256));//htotal

   	HDMI_WriteI2C_Byte(0xac,(u8)(video_format->vtotal/256));
	HDMI_WriteI2C_Byte(0xad,(u8)(video_format->vtotal%256));//vtotal

   	HDMI_WriteI2C_Byte(0xae,(u8)(video_format->hs/256)); 
	HDMI_WriteI2C_Byte(0xaf,(u8)(video_format->hs%256));   //hsa

    HDMI_WriteI2C_Byte(0xb0,(u8)(video_format->vs%256));    //vsa

    //dessc pll to generate pixel clk
	HDMI_WriteI2C_Byte(0xff,0x82); //dessc pll
	HDMI_WriteI2C_Byte(0x2d,0x48); //pll ref select xtal 

	if(pclk_khz < 44000)
	{
        HDMI_WriteI2C_Byte(0x35,0x83);
		dessc_pll_post_div = 16;
	}

	else if(pclk_khz < 88000)
	{
	  	HDMI_WriteI2C_Byte(0x35,0x82);
		dessc_pll_post_div = 8;
	}

	else if(pclk_khz < 176000)
	{
	  	HDMI_WriteI2C_Byte(0x35,0x81);
		dessc_pll_post_div = 4;
	}

	else if(pclk_khz < 352000)
	{
	  	HDMI_WriteI2C_Byte(0x35,0x80);
		dessc_pll_post_div = 0;
	}

	pcr_m = (pclk_khz * dessc_pll_post_div) /25;
	pcr_k = pcr_m%1000;
	pcr_m = pcr_m/1000;

	pcr_k <<= 14; 

	//pixel clk
 	HDMI_WriteI2C_Byte(0xff,0xd0); //pcr
	HDMI_WriteI2C_Byte(0x2d,0x7f);
	HDMI_WriteI2C_Byte(0x31,0x00);

	HDMI_WriteI2C_Byte(0x26,0x80|((u8)pcr_m));
	HDMI_WriteI2C_Byte(0x27,(u8)((pcr_k>>16)&0xff)); //K
	HDMI_WriteI2C_Byte(0x28,(u8)((pcr_k>>8)&0xff)); //K
	HDMI_WriteI2C_Byte(0x29,(u8)(pcr_k&0xff)); //K
}

void LT9211_MipiTxpll(void)
{
    u8 loopx;
	
    HDMI_WriteI2C_Byte(0xff,0x82);
    HDMI_WriteI2C_Byte(0x36,0x03); //b7:txpll_pd
    HDMI_WriteI2C_Byte(0x37,0x28);
    HDMI_WriteI2C_Byte(0x38,0x44);
    HDMI_WriteI2C_Byte(0x3a,0x93);
	
    HDMI_WriteI2C_Byte(0xff,0x87);
    HDMI_WriteI2C_Byte(0x13,0x00);
    HDMI_WriteI2C_Byte(0x13,0x80);
    mdelay(100);
    for(loopx = 0; loopx < 10; loopx++) //Check Tx PLL cal done
    {
			
        HDMI_WriteI2C_Byte(0xff,0x87);			
        if(HDMI_ReadI2C_Byte(0x1f)& 0x80)
        {
            if(HDMI_ReadI2C_Byte(0x20)& 0x80)
            {
                LT9211_DBG("\r\n LT9211 tx pll lock");
            }
            else
            {
                LT9211_DBG("\r\nLT9211 tx pll unlocked");
            }					
            LT9211_DBG("\r\nLT9211 tx pll cal done");
            break;
        }
        else
        {
            LT9211_DBG("\r\nLT9211 tx pll unlocked");
        }
    }	 		
}

void LT9211_MipiTxPhy(void)
{		
    HDMI_WriteI2C_Byte(0xff,0x82);
    HDMI_WriteI2C_Byte(0x62,0x00); //ttl output disable
    HDMI_WriteI2C_Byte(0x3b,0x32); //mipi en
    
    //HDMI_WriteI2C_Byte(0x48,0x5f); //Port A Lane P/N Swap
    //HDMI_WriteI2C_Byte(0x49,0x92); 
    //HDMI_WriteI2C_Byte(0x52,0x5f); //Port B Lane P/N Swap
    //HDMI_WriteI2C_Byte(0x53,0x92); 
	
    HDMI_WriteI2C_Byte(0xff,0x86);	
    HDMI_WriteI2C_Byte(0x40,0x80); //tx_src_sel
    /*port src sel*/
    HDMI_WriteI2C_Byte(0x41,0x01);	
    HDMI_WriteI2C_Byte(0x42,0x23);
    HDMI_WriteI2C_Byte(0x43,0x40); //Port A MIPI Lane Swap
    HDMI_WriteI2C_Byte(0x44,0x12);
    HDMI_WriteI2C_Byte(0x45,0x34); //Port B MIPI Lane Swap
}

void LT9211_MipiTxDigital(void)
{	
    HDMI_WriteI2C_Byte(0xff,0xd4);
	HDMI_WriteI2C_Byte(0x1c,0x30);  //hs_rqst_pre
	HDMI_WriteI2C_Byte(0x1d,0x0a);  //lpx
	HDMI_WriteI2C_Byte(0x1e,0x06);  //prpr
	HDMI_WriteI2C_Byte(0x1f,0x0a);  //trail
	HDMI_WriteI2C_Byte(0x21,0x00);  //[5]byte_swap,[0]burst_clk

    HDMI_WriteI2C_Byte(0xff,0xd4);	
    HDMI_WriteI2C_Byte(0x16,0x55);	
    HDMI_WriteI2C_Byte(0x10,0x01);
    HDMI_WriteI2C_Byte(0x11,0x50); //read delay
    HDMI_WriteI2C_Byte(0x13,0x22);	//bit[5:4]:lane num, bit[2]:bllp,bit[1:0]:vid_mode 
    HDMI_WriteI2C_Byte(0x14,0x20); //bit[5:4]:data typ,bit[2:0]:fmt sel 000:rgb888
    HDMI_WriteI2C_Byte(0x21,0x01);
}

void LT9211_SetTxTiming(void)
{
	u16 hact, vact;
    u16 hs, vs;
    u16 hbp, vbp;
    u16 htotal, vtotal;
    u16 hfp, vfp;	

    hact = pVideo_Format->hact;
    vact = pVideo_Format->vact;
    htotal = pVideo_Format->htotal;
    vtotal = pVideo_Format->vtotal;
    hs = pVideo_Format->hs;
    vs = pVideo_Format->vs;
    hfp = pVideo_Format->hfp;
    vfp = pVideo_Format->vfp; 
    hbp = pVideo_Format->hbp;
    vbp = pVideo_Format->vbp;
	
	HDMI_WriteI2C_Byte(0xff,0xd4);
	HDMI_WriteI2C_Byte(0x04,0x08); //hs[7:0] not care
	HDMI_WriteI2C_Byte(0x05,0x08); //hbp[7:0] not care
	HDMI_WriteI2C_Byte(0x06,0x08); //hfp[7:0] not care
	HDMI_WriteI2C_Byte(0x07,(u8)(hact>>8)); //hactive[15:8]
	HDMI_WriteI2C_Byte(0x08,(u8)(hact)); //hactive[7:0]
	
	HDMI_WriteI2C_Byte(0x09,(u8)(vs)); //vfp[7:0]
	HDMI_WriteI2C_Byte(0x0a,0x00); //bit[3:0]:vbp[11:8]
	HDMI_WriteI2C_Byte(0x0b,(u8)(vbp)); //vbp[7:0]
	HDMI_WriteI2C_Byte(0x0c,(u8)(vact>>8)); //vcat[15:8]
	HDMI_WriteI2C_Byte(0x0d,(u8)(vact)); //vcat[7:0]
	HDMI_WriteI2C_Byte(0x0e,(u8)(vfp>>8)); //vfp[11:8]
	HDMI_WriteI2C_Byte(0x0f,(u8)(vfp)); //vfp[7:0]
    
    LT9211_DBG("\r\n LT9211 LT9211_SetTxTiming() hfp, hs, hbp, hact, htotal = %d, %d, %d, %d, %d \n",hfp,hs,hbp,hact,htotal);
    LT9211_DBG("\r\n LT9211 LT9211_SetTxTiming() vfp, vs, vbp, vact, vtotal = %d, %d, %d, %d, %d \n",vfp,vs,vbp,vact,vtotal);

}

void LT9211_DebugInfo(void)
{
#ifdef _uart_debug_
	u32 fm_value;

	HDMI_WriteI2C_Byte(0xff,0x86);
	HDMI_WriteI2C_Byte(0x00,0x12);
	mdelay(100);
    fm_value = 0;
	fm_value = (HDMI_ReadI2C_Byte(0x08) &(0x0f));
    fm_value = (fm_value<<8) ;
	fm_value = fm_value + HDMI_ReadI2C_Byte(0x09);
	fm_value = (fm_value<<8) ;
	fm_value = fm_value + HDMI_ReadI2C_Byte(0x0a);
	LT9211_DBG("\r\n LT9211 mipi output byte clock: %x", fm_value);
    
	HDMI_WriteI2C_Byte(0xff,0x86);
	HDMI_WriteI2C_Byte(0x00,0x0a);
	mdelay(100);
    fm_value = 0;
	fm_value = (HDMI_ReadI2C_Byte(0x08) &(0x0f));
    fm_value = (fm_value<<8) ;
	fm_value = fm_value + HDMI_ReadI2C_Byte(0x09);
	fm_value = (fm_value<<8) ;
	fm_value = fm_value + HDMI_ReadI2C_Byte(0x0a);
	LT9211_DBG("\r\n LT9211 output pixclk: %x",fm_value);
#endif
}

void LT9211_MIPI_Pattern_Config(void)
{
    LT9211_DBG("\r\n*************LT9211 MIPI Pattern Config************* \n\n");
    LT9211_ChipID();
    LT9211_SystemInt();
    
    pVideo_Format = &video_1280x720_60Hz;
    
    LT9211_Patten(pVideo_Format);
    
    LT9211_MipiTxPhy();
	LT9211_MipiTxpll();
	LT9211_SetTxTiming();
    //InitPanel();
	LT9211_MipiTxDigital();
    LT9211_DebugInfo();
}



#ifdef BUILD_LK //lk i2c define
#define LT9211_SLAVE_ADDR  0x2d
struct mt_i2c_t lt9211_i2c;

/* ---------------------------------------------------------------------------------------------------------------------------------*/
int lt9211_write_byte(u8 addr, u8 value)
{
    int ret_code = 0;
    u8 write_data[2];
    unsigned int len;

    write_data[0] = addr;
    write_data[1] = value;

    lt9211_i2c.id = 1; /* I2C0; */
    lt9211_i2c.addr = (LT9211_SLAVE_ADDR);
    lt9211_i2c.mode = ST_MODE;
    lt9211_i2c.speed = 100;
    len = 2;

    ret_code = i2c_write(&lt9211_i2c, write_data, len);
	if(ret_code < 0)
	    printf("%s: lt9211_write_byte error: ret_code: %d\n", __func__, ret_code); 

	printf("%s: lk success: ret_code: %d\n", __func__, ret_code);
	
    return ret_code;
}

int lt9211_read_byte(u8 addr, u8 *dataBuffer)
{
	int ret_code = 0;
    unsigned int len;
	*dataBuffer = addr;

    lt9211_i2c.id = 1; /* I2C0; */
    lt9211_i2c.addr = (LT9211_SLAVE_ADDR);
    lt9211_i2c.mode = ST_MODE;
    lt9211_i2c.speed = 100;
	lt9211_i2c.st_rs = I2C_TRANS_REPEATED_START;
    len = 1;

	ret_code = i2c_write_read(&lt9211_i2c, dataBuffer, len, len);
	if(ret_code < 0)
		printf("%s:  lk error : ret_code: %d,ic:0x%x\n", __func__, ret_code, *dataBuffer); 


	printf("%s: lk success: ret_code: %d, dataBuffer = %x\n", __func__, ret_code, *dataBuffer); 

    return ret_code;
}

#else
#define I2C_LT9211_ID_NAME "lt9211"
static const struct of_device_id lt9211_of_match[] = {
    {.compatible = "mediatek,LT9211"},
    {},
};
	
static struct i2c_client *lt9211_i2c_client;
static DEFINE_MUTEX(lt9211_i2c_access);
static int lt9211_probe(struct i2c_client *client, const struct i2c_device_id *id);
static int lt9211_remove(struct i2c_client *client);

struct lt9211_dev {
    struct i2c_client *client;
};

static const struct i2c_device_id lt9211_id[] = {
    {I2C_LT9211_ID_NAME, 0},
    {}
};


static struct i2c_driver lt9211_iic_driver = {
    .id_table = lt9211_id,
    .probe = lt9211_probe,
    .remove = lt9211_remove,
    .driver = {
        .owner = THIS_MODULE,
        .name = "lt9211",
        .of_match_table = lt9211_of_match,
    },
};
		

static int i2c_write_byte(struct i2c_client *client, u8 reg, u8 val)
{
	int rc = 0;
	u8 txbuf[512] = {0};

	if(!client)
	{
		//printk("%s i2c_write_byte-> client == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = {
		{
		.addr = client->addr,
		.flags = 0,
		.len = 2,
		.buf = txbuf,
		},
	};

	txbuf[0] = reg;
	txbuf[1] = val;
	
	rc = i2c_transfer(client->adapter, msg, 1);
	if(rc < 0)
	{
		printk("%s i2c_transfer i2c write error rc= 0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	printk("%s lt9211 success rc= 0d[%d]\n", __func__, rc);

	return rc;
}

static int i2c_read_byte(struct i2c_client *client, u8 reg, u8 *buf, u32 size)
{
	int rc = 0;
	u8 rxbuf[512] = {0};

	if(!client || !buf)
	{
		//printk("%s i2c_write_byte-> client == null || buf == null \n", __func__);
		return -EINVAL;
	}

	struct i2c_msg msg[] = 
	{
		{
			.addr = client->addr,
			.flags = 0,
			.len = 1,
			.buf = rxbuf,
		},
		{
			.addr = client->addr,
			.flags = I2C_M_RD,
			.len = 1,
			.buf = rxbuf,
		},
	};

	rxbuf[0] = reg;
	
	printk("%s addr = %x \n", __func__, client->addr);
	rc = i2c_transfer(client->adapter, msg, 2);
	if(rc < 0)
	{
		printk("%s i2c_transfer error rc=0d%d\n", __func__, rc);
		//rc = -EIO;
		return rc;
	}

	*buf = rxbuf[0];
	printk("%s lt9211 success rc=0d[%d], rxbuf[0] = 0x%x, *buf = 0x%x\n", __func__, rc, rxbuf[0], *buf);

	return rc;
}

int lt9211_write_bytes(u8 cmd, u8 writeData)
{
	int ret = 0;
#if 0
	u8 b[2];
	struct i2c_msg msg;

	if(lt9211_i2c_client == NULL)
	{
		printk("lt9211_write_bytes lt9211_i2c_client == NULL !!\n");
		return -1;
	}

	b[0] = cmd;				/* 寄存器首地址 */
	memcpy(&b[1],writeData,1);	/* 将要写入的数据拷贝到数组 b 里面  */

	msg.addr  = lt9211_i2c_client->addr;/* lt9211地址 */
	msg.flags = 0;           /* 标记为写数据 */
	msg.buf   = b;           /* 要写入的数据缓冲区 */
	msg.len   = 2;     /* 要写入的数据长度 */

	ret = i2c_transfer(lt9211_i2c_client->adapter, &msg, 1);
	
#else
	if(lt9211_i2c_client == NULL)
	{
		printk("lt9211_write_bytes lt9211_i2c_client == NULL !!\n");
		return -1;
	}
	mutex_lock(&lt9211_i2c_access);

	ret = i2c_write_byte(lt9211_i2c_client, cmd, writeData);
	if (ret < 0)
	{
		mutex_unlock(&lt9211_i2c_access);
		printk("lt9211_write_bytes i2c_master_send fail ret= 0d%d!!\n", ret);
		
		return ret;
	}
	mutex_unlock(&lt9211_i2c_access);
	printk("%s success end ret=0d%d \n", __func__, ret);

#endif
	return ret;
}
EXPORT_SYMBOL(lt9211_write_bytes);

int lt9211_read_bytes(u8 cmd, u8 *returnData)
{
	int ret = 0;
#if 0
	struct i2c_msg msg[2];

	if(lt9211_i2c_client == NULL) 
	{
	   printk(" lt9211_read_bytes lt9211_i2c_client == NULL \n");
	   return -1;
	}

	/* msg[0]为发送要读取的首地址 */
	msg[0].addr = lt9211_i2c_client->addr; /* lt9211 地址 */
	msg[0].flags = 0; 			/* 标记为发送数据 */
	msg[0].buf = &cmd; 			/* 读取的首地址 */
	msg[0].len = 1; 			/* reg 长度 */

	/* msg[1]读取数据 */
	msg[1].addr = lt9211_i2c_client->addr; /* lt9211 地址 */
	msg[1].flags = I2C_M_RD;    /* 标记为读取数据  */
	msg[1].buf = returnData;           /* 读取数据缓冲区 */
	msg[1].len = 1; 			/* 要读取的数据长度 */

	ret = i2c_transfer(lt9211_i2c_client->adapter, msg, 2);
	if(ret == 2) {
		ret = 0;
	} else {
		printk(KERN_ALERT"i2c rd failed=%d reg=%06x \n",ret, cmd);
		ret = -EREMOTEIO;
	}
#else
	u8 readData = 0;
	
	if(lt9211_i2c_client == NULL) 
	{
	   printk(" lt9211_read_bytes lt9211_i2c_client == NULL \n");
	   return -1;
	}
	mutex_lock(&lt9211_i2c_access);

	ret = i2c_read_byte(lt9211_i2c_client, cmd, &readData, 1);
	if (ret < 0)
	{
		mutex_unlock(&lt9211_i2c_access);
		printk("lt9211_write_bytes i2c_master_send fail ret= 0d%d!!\n", ret);
		
		return ret;
	}
	*returnData = readData;	

	mutex_unlock(&lt9211_i2c_access);
	printk("%s success end ret=0d%d readData=0x%x\n", __func__, ret, readData);

#endif
	return ret;
}
EXPORT_SYMBOL(lt9211_read_bytes);


static int lt9211_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    printk("lt9211_iic_probe\n");
    printk("%s ==>name=%s addr=0x%x\n", __func__, client->name, client->addr);
    lt9211_i2c_client = client;
    return 0;
}
static int lt9211_remove(struct i2c_client *client)
{
    printk("lt9211_remove\n");
    lt9211_i2c_client = NULL;
    i2c_unregister_device(client);
    return 0;
}


static int __init lt9211_init(void)
{
    printk("lt9211_iic_init\n");

    i2c_add_driver(&lt9211_iic_driver);

    printk("lt9211_iic_init success\n");
    return 0;
}
static void __exit lt9211_exit(void)
{
    printk("lt9211_iic_exit\n");
    i2c_del_driver(&lt9211_iic_driver);

}
module_init(lt9211_init);
module_exit(lt9211_exit);
MODULE_AUTHOR("Xiaokuan Shi");
MODULE_DESCRIPTION("MTK lt9211 I2C Driver");
#endif

