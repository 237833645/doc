#ifndef __DEV_ISL97900_EXT_H_
#define __DEV_ISL97900_EXT_H_

#if defined(BUILD_LK)
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#else
#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/i2c.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <mt-plat/mt_gpio.h>
#include <mach/gpio_const.h>
#include <linux/input.h>
#include <linux/printk.h>
#include <linux/proc_fs.h> //proc file use
#endif


#define  _DEVISL97900_EXT_GLOBALS


#ifdef   _DEVISL97900_EXT_GLOBALS
	#define  DEVISL97900_EXT
#else
	#define  DEVISL97900_EXT  extern
#endif


typedef signed char         int8_t;
typedef unsigned char       uint8_t;
typedef signed short        int16_t;
typedef unsigned short      uint16_t;
typedef signed int          int32_t;
typedef unsigned int        uint32_t;
typedef unsigned char		BOOLEAN_TypeDef;



#define	ISL97900_DEVICE_ADR					0x50

#define ISL97900_STATUSREG					0x01


typedef struct
{
	uint8_t Addr;
	uint8_t Data;
}ISL_TypeDef;


typedef struct
{
	uint8_t RedLEDLSB;
	uint8_t GreenLEDLSB;
	uint8_t BlueLEDLSB;
	uint8_t RGBLEDMSB;
}ISL_Current;


#define CURRENT_SET							16
#define CURRENT_REDLSB_REG					0x13
#define CURRENT_GREENLSB_REG				0x14
#define CURRENT_BLUELSB_REG					0x15
#define CURRENT_RGBMSB_REG					0x17

#define ISL97900_CEN0_GPIO_PORT
#define ISL97900_CEN0_PIN
#define	P_ISL97900_CEN0_Set_Output
#define	P_ISL97900_CEN0_H
#define	P_ISL97900_CEN0_L

#if ISL97900_DEV_CHx >= 2
#define ISL97900_CEN1_GPIO_PORT
#define ISL97900_CEN1_PIN
#define	P_ISL97900_CEN1_Set_Output
#define	P_ISL97900_CEN1_H
#define	P_ISL97900_CEN1_L
#endif

#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE  0
#endif


#if defined(BUILD_LK)
#define MDELAY(n)   mdelay(n)  
#else
extern void msleep(unsigned int msecs);
#define MDELAY(n)   msleep(n)  
#endif


//DEVISL97900_EXT ISL_Current Isl97900_GainDAC[];
#ifdef BUILD_LK
uint32_t isl97900_r_write_byte(uint8_t addr, uint8_t value);
uint32_t isl97900_r_read_byte(uint8_t addr, uint8_t *dataBuffer);
uint32_t isl97900_l_write_byte(uint8_t addr, uint8_t value);
uint32_t isl97900_l_read_byte(uint8_t addr, uint8_t *dataBuffer);
#else
int isl97900_r_write_bytes(uint8_t cmd, uint8_t writeData);
int isl97900_r_read_bytes(uint8_t cmd, uint8_t *returnData);
int isl97900_l_write_bytes(uint8_t cmd, uint8_t writeData);
int isl97900_l_read_bytes(uint8_t cmd, uint8_t *returnData);
#endif

DEVISL97900_EXT BOOLEAN_TypeDef DevISL97900_l_Init(uint8_t ch);
DEVISL97900_EXT BOOLEAN_TypeDef isl97900_l_Write_Current(uint8_t ch, uint8_t vol);

DEVISL97900_EXT BOOLEAN_TypeDef DevISL97900_r_Init(uint8_t ch);
DEVISL97900_EXT BOOLEAN_TypeDef isl97900_r_Write_Current(uint8_t ch, uint8_t vol);







#endif
