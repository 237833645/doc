
#ifndef _LT9211_H_
#define _LT9211_H_

#if defined(BUILD_LK)
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#else
#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/i2c.h>
#include <linux/irq.h>
#include <linux/io.h>
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_gpio.h>
#include <linux/of_irq.h>
#include <mt-plat/mt_gpio.h>
#include <mach/gpio_const.h>
#include <linux/input.h>
#include <linux/printk.h>
#include <linux/proc_fs.h> //proc file use
#endif


#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE  0
#endif


#if defined(BUILD_LK)
#define LT9211_DBG    	printf
#else
#define LT9211_DBG		printk
#endif

#ifndef u16
#define u16 unsigned short
#endif
#ifndef u8
#define u8 unsigned char
#endif
#ifndef u32
#define u32 unsigned int
#endif



/******************* MIPI Input Config ********************/
//#define MIPI_CSI

//#define INPUT_PORTA
#define INPUT_PORTB

#define Lane_Num 4
/******************* MIPI Input Config ********************/

/******************* Lvds Output Config ********************/
typedef enum LT9211_LVDSPORT_ENUM
{
    LVDS_1PORT = 0,
    LVDS_2PORT = 1
};
#define LVDS_PORTNUM LVDS_2PORT

typedef enum LT9211_LVDSMODE_ENUM
{
    DE_MODE = 0,
    SYNC_MODE = 1
};
#define LVDS_MODE SYNC_MODE

typedef enum LT9211_LVDSDATAFORMAT_ENUM
{
    VESA = 0,
    JEIDA = 1
};
#define LVDS_DATAFORMAT VESA

typedef enum LT9211_LVDSCOLORDEPTH_ENUM
{
    DEPTH_6BIT = 0,
    DEPTH_8BIT = 1
};
#define LVDS_COLORDEPTH DEPTH_8BIT

//#define LVDS_2PORT_SWAP

/******************* Lvds Output Config ********************/

typedef struct video_timing{
u16 hfp;
u16 hs;
u16 hbp;
u16 hact;
u16 htotal;
u16 vfp;
u16 vs;
u16 vbp;
u16 vact;
u16 vtotal;
u32 pclk_khz;
};


#ifndef NULL
# define NULL ((void *)0)
#endif

#if defined(BUILD_LK)
#define MDELAY(n)   mdelay(n)  
#else
extern void msleep(unsigned int msecs);
#define MDELAY(n)   msleep(n)  
#endif


#if defined(BUILD_LK)
int lt9211_write_byte(u8 addr, u8 value);
int lt9211_read_byte(u8 addr, u8 *dataBuffer);
#else
int lt9211_write_bytes(u8 cmd, u8 writeData);
int lt9211_read_bytes(u8 cmd, u8 *returnData);
#endif

void LT9211_MIPI_Pattern_Config(void);
void LT9211_MIPI2MIPI_Config(void);


#endif
