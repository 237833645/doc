#include "lcd_gpio.h"


#ifdef BUILD_LK

/*  
*
*  gpio ctl
*/
/*
//-#define GPIO_LT9211_INT              (GPIO3  | 0x80000000)
-#define GPIO_OVP0921_PWR_EN            (GPIO68 | 0x80000000)
-#define GPIO_OVP0921_L_RST     		(GPIO77 | 0x80000000)
-#define GPIO_OVP0921_R_RST     		(GPIO58 | 0x80000000)
-#define GPIO_OVP2200_PWR_EN            (GPIO67 | 0x80000000)
-#define GPIO_LT9211_PWR_EN             (GPIO65 | 0x80000000)
-#define GPIO_LT9211_RST                (GPIO66 | 0x80000000)
-#define GPIO_ISL_97900_CE              (GPIO76 | 0x80000000)  EB_BL



GPIO_OVP2200_PWR_EN		gpio_ctrl_1		GPIO67
GPIO_OVP0921_PWR_EN 	gpio_ctrl_2		GPIO68
GPIO_LT9211_PWR_EN		gpio_ctrl_3		GPIO65
GPIO_LT9211_RST			gpio_ctrl_4		GPIO66
GPIO_OVP0921_L_RST		gpio_ctrl_5		GPIO77
GPIO_OVP0921_R_RST		gpio_ctrl_6		GPIO58
GPIO_ISL_97900_CE		gpio_ctrl_7		GPIO76

*/
#define GPIO_LT9211_INT				(GPIO3	| 0x80000000)
#define GPIO_OVP0921_PWR_EN			(GPIO68 | 0x80000000)
#define GPIO_OVP0921_L_RST 			(GPIO77 | 0x80000000)
#define GPIO_OVP0921_R_RST 			(GPIO58 | 0x80000000)
#define GPIO_OVP2200_PWR_EN			(GPIO67 | 0x80000000)
#define GPIO_LT9211_PWR_EN 			(GPIO65 | 0x80000000)
#define GPIO_LT9211_RST				(GPIO66 | 0x80000000)
#define GPIO_ISL_97900_CE			(GPIO76 | 0x80000000)  //EB_BL

void gpio_lcd_init(void)
{
	printf("gpio_lcd_init start\n");
	mt_set_gpio_mode(GPIO_OVP2200_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP2200_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP2200_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_OVP0921_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP0921_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP0921_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_LT9211_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_LT9211_PWR_EN, 1);
	mt_set_gpio_out(GPIO_LT9211_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_LT9211_RST, 0);
	mt_set_gpio_dir(GPIO_LT9211_RST, 1);
	mt_set_gpio_out(GPIO_LT9211_RST, 0);

	mt_set_gpio_mode(GPIO_OVP0921_L_RST, 0);
	mt_set_gpio_dir(GPIO_OVP0921_L_RST, 1);
	mt_set_gpio_out(GPIO_OVP0921_L_RST, 0);

	mt_set_gpio_mode(GPIO_OVP0921_R_RST, 0);
	mt_set_gpio_dir(GPIO_OVP0921_R_RST, 1);
	mt_set_gpio_out(GPIO_OVP0921_R_RST, 0);	

	mt_set_gpio_mode(GPIO_ISL_97900_CE, 0);
	mt_set_gpio_dir(GPIO_ISL_97900_CE, 1);
	mt_set_gpio_out(GPIO_ISL_97900_CE, 0);
	printf("gpio_lcd_init end\n");
}

void gpio_lcd_powerup(void)
{
	printf("gpio_lcd_power_up start\n");
	mt_set_gpio_mode(GPIO_OVP2200_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP2200_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP2200_PWR_EN, 1);

	mt_set_gpio_mode(GPIO_OVP0921_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP0921_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP0921_PWR_EN, 1);

	mt_set_gpio_mode(GPIO_LT9211_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_LT9211_PWR_EN, 1);
	mt_set_gpio_out(GPIO_LT9211_PWR_EN, 1);

	mt_set_gpio_mode(GPIO_ISL_97900_CE, 0);
	mt_set_gpio_dir(GPIO_ISL_97900_CE, 1);
	mt_set_gpio_out(GPIO_ISL_97900_CE, 1);

	printf("gpio_lcd_power_up end\n");
}

void gpio_lcd_powerdown(void)
{
	printf("gpio_lcd_power_down start\n");
	mt_set_gpio_mode(GPIO_OVP2200_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP2200_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP2200_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_OVP0921_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_OVP0921_PWR_EN, 1);
	mt_set_gpio_out(GPIO_OVP0921_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_LT9211_PWR_EN, 0);
	mt_set_gpio_dir(GPIO_LT9211_PWR_EN, 1);
	mt_set_gpio_out(GPIO_LT9211_PWR_EN, 0);

	mt_set_gpio_mode(GPIO_ISL_97900_CE, 0);
	mt_set_gpio_dir(GPIO_ISL_97900_CE, 1);
	mt_set_gpio_out(GPIO_ISL_97900_CE, 0);

	printf("gpio_lcd_power_down end\n");
}

void LT9211_RST(void)
{
	printf("LT9211_RST start\n");

	mt_set_gpio_mode(GPIO_LT9211_RST, 0);
	mt_set_gpio_dir(GPIO_LT9211_RST, 1);
	mt_set_gpio_out(GPIO_LT9211_RST, 0);
	mdelay(100);
	mt_set_gpio_out(GPIO_LT9211_RST, 1);
	mdelay(100);
	printf("LT9211_RST end\n");
}

void LT9211_POWERDOWN(void)
{
	printf("LT9211_POWERDOWN start\n");
	mt_set_gpio_mode(GPIO_LT9211_RST, 0);
	mt_set_gpio_dir(GPIO_LT9211_RST, 1);
	mt_set_gpio_out(GPIO_LT9211_RST, 0);
	printf("LT9211_POWERDOWN end\n");	
}

void OVP0921_RST(int ch)
{
	printf("OVP0921_RST start\n");

	if(ch == 0){
		mt_set_gpio_mode(GPIO_OVP0921_L_RST, 0);
		mt_set_gpio_dir(GPIO_OVP0921_L_RST, 1);
		mt_set_gpio_out(GPIO_OVP0921_L_RST, 0);
		mdelay(20);
		mt_set_gpio_out(GPIO_OVP0921_L_RST, 1);
		mdelay(200);
		mt_set_gpio_out(GPIO_OVP0921_L_RST, 0);
	}
	else if(ch == 1)
	{
		mt_set_gpio_mode(GPIO_OVP0921_R_RST, 0);
		mt_set_gpio_dir(GPIO_OVP0921_R_RST, 1);
		mt_set_gpio_out(GPIO_OVP0921_R_RST, 0);
		mdelay(20);
		mt_set_gpio_out(GPIO_OVP0921_R_RST, 1); 
		mdelay(200);
		mt_set_gpio_out(GPIO_OVP0921_R_RST, 0); 
	}

	printf("OVP0921_RST end\n");
}

void ISL_97900_RST(void)
{
	printf("ISL_97900_RST start\n");

	mt_set_gpio_mode(GPIO_ISL_97900_CE, 0);
	mt_set_gpio_dir(GPIO_ISL_97900_CE, 1);
	mt_set_gpio_out(GPIO_ISL_97900_CE, 1);
	mdelay(200);
	printf("ISL_97900_RST end\n");
}


#else

static struct pinctrl *gpio_ctrl_pin_ctrl		= NULL;
static struct pinctrl_state *gpio_ctrl_1_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_1_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_2_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_2_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_3_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_3_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_4_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_4_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_5_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_5_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_6_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_6_low 	= NULL;
static struct pinctrl_state *gpio_ctrl_7_high  	= NULL;
static struct pinctrl_state *gpio_ctrl_7_low 	= NULL;


static dev_t gpio_ctrl_devno;
static struct class *gpio_ctrl_class = NULL;
static struct device *gpio_ctrl_devices = NULL;
#define GPIO_CTRL_DEVNAME            "gpio_ctrl"


static int gpio_ctrl_pinctrl_init(struct platform_device *pdev)
{
	int ret = 0;
	//GPIO_CTRL_FUNC();
	gpio_ctrl_pin_ctrl = devm_pinctrl_get(&pdev->dev);
	if (IS_ERR(gpio_ctrl_pin_ctrl)) {
		dev_err(&pdev->dev, "Cannot find gpio_ctrl_pin_ctrl!");
		ret = PTR_ERR(gpio_ctrl_pin_ctrl);
		printk("%s devm_pinctrl_get fail!\n", __func__);
	}
	
	/*ctrl 1 */
	gpio_ctrl_1_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_1_high");
	if (IS_ERR(gpio_ctrl_1_high)) {
		ret = PTR_ERR(gpio_ctrl_1_high);
		printk("%s : pinctrl err, gpio_ctrl_1_high\n", __func__);
	}

	gpio_ctrl_1_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_1_low");
	if (IS_ERR(gpio_ctrl_1_low)) {
		ret = PTR_ERR(gpio_ctrl_1_low);
		printk("%s : pinctrl err, gpio_ctrl_1_low\n", __func__);
	}
	
	/*ctrl 2 */
	gpio_ctrl_2_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_2_high");
	if (IS_ERR(gpio_ctrl_2_high)) {
		ret = PTR_ERR(gpio_ctrl_2_high);
		printk("%s : pinctrl err, gpio_ctrl_2_high\n", __func__);
	}

	gpio_ctrl_2_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_2_low");
	if (IS_ERR(gpio_ctrl_2_low)) {
		ret = PTR_ERR(gpio_ctrl_2_low);
		printk("%s : pinctrl err, gpio_ctrl_2_low\n", __func__);
	}
	
	/*ctrl 3 */
	gpio_ctrl_3_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_3_high");
	if (IS_ERR(gpio_ctrl_3_high)) {
		ret = PTR_ERR(gpio_ctrl_3_high);
		printk("%s : pinctrl err, gpio_ctrl_3_high\n", __func__);
	}

	gpio_ctrl_3_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_3_low");
	if (IS_ERR(gpio_ctrl_3_low)) {
		ret = PTR_ERR(gpio_ctrl_3_low);
		printk("%s : pinctrl err, gpio_ctrl_3_low\n", __func__);
	}
	
	/*ctrl 4 */ 
	gpio_ctrl_4_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_4_high");
	if (IS_ERR(gpio_ctrl_4_high)) {
		ret = PTR_ERR(gpio_ctrl_4_high);
		printk("%s : pinctrl err, gpio_ctrl_4_high\n", __func__);
	}

	gpio_ctrl_4_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_4_low");
	if (IS_ERR(gpio_ctrl_4_low)) {
		ret = PTR_ERR(gpio_ctrl_4_low);
		printk("%s : pinctrl err, gpio_ctrl_4_low\n", __func__);
	}
	
	/*ctrl 5 */ 
	gpio_ctrl_5_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_5_high");
	if (IS_ERR(gpio_ctrl_5_high)) {
		ret = PTR_ERR(gpio_ctrl_5_high);
		printk("%s : pinctrl err, gpio_ctrl_5_high\n", __func__);
	}

	gpio_ctrl_5_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_5_low");
	if (IS_ERR(gpio_ctrl_5_low)) {
		ret = PTR_ERR(gpio_ctrl_5_low);
		printk("%s : pinctrl err, gpio_ctrl_5_low\n", __func__);
	}

	/*ctrl 6 */ 
	gpio_ctrl_6_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_6_high");
	if (IS_ERR(gpio_ctrl_6_high)) {
		ret = PTR_ERR(gpio_ctrl_6_high);
		printk("%s : pinctrl err, gpio_ctrl_6_high\n", __func__);
	}

	gpio_ctrl_6_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_6_low");
	if (IS_ERR(gpio_ctrl_6_low)) {
		ret = PTR_ERR(gpio_ctrl_6_low);
		printk("%s : pinctrl err, gpio_ctrl_6_low\n", __func__);
	}

	/*ctrl 7 */ 
	gpio_ctrl_7_high = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_7_high");
	if (IS_ERR(gpio_ctrl_7_high)) {
		ret = PTR_ERR(gpio_ctrl_7_high);
		printk("%s : pinctrl err, gpio_ctrl_7_high\n", __func__);
	}

	gpio_ctrl_7_low = pinctrl_lookup_state(gpio_ctrl_pin_ctrl, "gpio_ctrl_7_low");
	if (IS_ERR(gpio_ctrl_7_low)) {
		ret = PTR_ERR(gpio_ctrl_7_low);
		printk("%s : pinctrl err, gpio_ctrl_7_low\n", __func__);
	}

	
	return ret;
}

static ssize_t gpio_ctrl_set_en(struct device *dev,struct device_attribute *attr, const char *buf, size_t count)
{
	int status = 0;
	int pinctrl_num = 0;
	//GPIO_CTRL_FUNC();
	sscanf(buf, "%d %d", &pinctrl_num, &status);
	
	if(gpio_ctrl_pin_ctrl == NULL){
		printk("\n\n\n\n\ gpio_ctrl_pin_ctrl == 0 Ponit Error !!!!!!!!!!!!! \n\n\n\n");
		return -1;
	}
	
	if(status){
		switch (pinctrl_num){
			case 1:
				if(gpio_ctrl_1_high != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_high);
				break;
			case 2:
				if(gpio_ctrl_2_high != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_high);
				break;
			case 3:
				if(gpio_ctrl_3_high != 0)			
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_high);
				break;
			case 4:
				if(gpio_ctrl_4_high != 0)						
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_high);
				break;
			case 5:
				if(gpio_ctrl_5_high != 0)									
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_high);
				break;
			case 6:
				if(gpio_ctrl_6_high != 0)									
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_high);
				break;
			case 7:
				if(gpio_ctrl_7_high != 0)									
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_high);
				break;				
			default:
				break;
		}
		
	} else {
		switch (pinctrl_num){
			case 1:
				if(gpio_ctrl_1_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_low);
				break;
			case 2:
				if(gpio_ctrl_2_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_low);
				break;
			case 3:
				if(gpio_ctrl_3_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_low);
				break;
			case 4:
				if(gpio_ctrl_4_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_low);
				break;
			case 5:
				if(gpio_ctrl_5_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_low);
				break;
			case 6:
				if(gpio_ctrl_6_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_low);
				break;
			case 7:
				if(gpio_ctrl_7_low != 0)
					pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_low);
				break;				
			default:
				break;
		}
	}
	return count;
}

static ssize_t gpio_ctrl_get_en(struct device *dev, struct device_attribute *attr, char *buf)
{
	//unsigned char reg_val;
	ssize_t len = 0;
	//u8 i;
	//for (i = 0; i < 0x30; i++)
	//{
	//	reg_val = i2c_read_reg(i);
	//	len += snprintf(buf + len, PAGE_SIZE - len, "reg%2X = 0x%2X,\n", i, reg_val);
	//}

	return len;
}


static DEVICE_ATTR(gpio_ctrl_en, 0660, gpio_ctrl_get_en,  gpio_ctrl_set_en);

static struct device_attribute *gpio_ctrl_attr_list[] = {
	&dev_attr_gpio_ctrl_en,
};

static int gpio_ctrl_create_attr(struct device *dev)
{
	int idx, err = 0;
	//GPIO_CTRL_FUNC();
	int num =
		(int) sizeof(gpio_ctrl_attr_list) /
		sizeof(gpio_ctrl_attr_list[0]);

	if (!dev)
		return -EINVAL;

	for (idx = 0; idx < num; idx++) {
		device_create_file(dev, gpio_ctrl_attr_list[idx]);
	}

	return err;
}


void gpio_lcd_init(void)
{
	printk("%s %d\n",__func__,__LINE__);
	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_1_low != 0 && gpio_ctrl_2_low != 0 \
		&& gpio_ctrl_3_low != 0 && gpio_ctrl_4_low != 0 && gpio_ctrl_5_low != 0 \
		&& gpio_ctrl_6_low != 0 && gpio_ctrl_7_low != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_low);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_low);	
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_low);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_low);	//GPIO_LT9211_RST
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_low); 	//GPIO_OVP0921_L_RST
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_low);	//GPIO_OVP0921_R_RST
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_low);	//GPIO_ISL_97900_CE	
	}
	printk("%s %d\n",__func__,__LINE__);
		
}
EXPORT_SYMBOL(gpio_lcd_init);

void gpio_lcd_powerup(void)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_1_high != 0 && gpio_ctrl_2_high != 0 \
		&& gpio_ctrl_3_high != 0 && gpio_ctrl_7_high != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_high);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_high);	
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_high);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_high);	//GPIO_ISL_97900_CE	
	}
	printk("%s %d\n",__func__,__LINE__);
}
EXPORT_SYMBOL(gpio_lcd_powerup);

void gpio_lcd_powerdown(void)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_1_low != 0 && gpio_ctrl_2_low != 0 \
		&& gpio_ctrl_3_low != 0 && gpio_ctrl_7_low != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_1_low);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_2_low);	
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_3_low);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_low);	//GPIO_ISL_97900_CE	
	}
	printk("%s %d\n",__func__,__LINE__);

}
EXPORT_SYMBOL(gpio_lcd_powerdown);


void LT9211_RST(void)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_4_low != 0 && gpio_ctrl_4_high != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_low);
		MDELAY(100);
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_high);
		MDELAY(100);
	}
	printk("%s %d\n",__func__,__LINE__);

}
EXPORT_SYMBOL(LT9211_RST);


void LT9211_POWERDOWN(void)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_4_low != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_4_low);
	}
	printk("%s %d\n",__func__,__LINE__);

}
EXPORT_SYMBOL(LT9211_POWERDOWN)

void OVP0921_RST(int ch)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_5_low != 0 && gpio_ctrl_5_high != 0 && gpio_ctrl_6_low != 0 && gpio_ctrl_6_high != 0)
	{
		if(ch == 0){
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_low);	//GPIO_ISL_97900_CE  L
			MDELAY(20);
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_high);	//GPIO_ISL_97900_CE
			MDELAY(200);
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_5_low);	//GPIO_ISL_97900_CE	

		}
		else if(ch == 1)
		{
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_low);	//GPIO_ISL_97900_CE  R 
			MDELAY(20);
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_high);	//GPIO_ISL_97900_CE 	
			MDELAY(200);
			pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_6_low);	//GPIO_ISL_97900_CE
		}
		
	}
	printk("%s %d\n",__func__,__LINE__);

}
EXPORT_SYMBOL(OVP0921_RST);


void ISL_97900_RST(void)
{
	printk("%s %d\n",__func__,__LINE__);

	if(gpio_ctrl_pin_ctrl != 0 && gpio_ctrl_7_high != 0)
	{
		pinctrl_select_state(gpio_ctrl_pin_ctrl, gpio_ctrl_7_high);	//	GPIO_ISL_97900_CE
		MDELAY(200);
	}
	printk("%s %d\n",__func__,__LINE__);
	
}
EXPORT_SYMBOL(ISL_97900_RST);

static int gpio_ctrl_probe(struct platform_device *pdev)
{
	int ret = 0;

	//GPIO_CTRL_FUNC();
	
	ret = gpio_ctrl_pinctrl_init(pdev);
	if (ret != 0) {
		printk("[%s] failed to init gpio_ctrl pinctrl.\n", __func__);
		return ret;
	} else {
		printk("[%s] Success to init gpio_ctrl pinctrl.\n", __func__);
	}

	ret = alloc_chrdev_region(&gpio_ctrl_devno,0,1,GPIO_CTRL_DEVNAME);
	if(ret){
		printk("[gpio_ctrl] alloc_chrdev_region fail: %d\n", ret);
		goto exit_check_functionality_failed;
	}else{
		printk("[gpio_ctrl] major: %d, minor: %d\n",
			   MAJOR(gpio_ctrl_devno), MINOR(gpio_ctrl_devno));
	}

	gpio_ctrl_class = class_create(THIS_MODULE,"gpio_ctrl");
	if (IS_ERR(gpio_ctrl_class)) {
		printk("[gpio_ctrl_probe] Unable to create class, err = %d\n",(int) PTR_ERR(gpio_ctrl_class));
		goto exit_check_functionality_failed;
	}
	
	gpio_ctrl_devices = (struct device *)device_create(gpio_ctrl_class, NULL, gpio_ctrl_devno, NULL, GPIO_CTRL_DEVNAME);
	if (NULL == gpio_ctrl_devices) {
		printk("[gpio_ctrl_probe] device_create fail\n");
		goto exit_check_functionality_failed;
	}

	
	if (gpio_ctrl_create_attr(gpio_ctrl_devices))
		printk("[gpio_ctrl_probe] create_attr fail\n");

	printk("[%s] success init end \n", __func__);

	//gpio_lcd_init();

	
	return 0;
	
	exit_check_functionality_failed:
	return ret; 

}


static int gpio_ctrl_remove(struct platform_device *pdev)
{
	//GPIO_CTRL_FUNC();
	return 0;
}

#ifdef CONFIG_OF
	static const struct of_device_id gpio_ctrl_of_match[] = {
		{ .compatible = "mediatek,gpio_ctrl",},
		{},
};
#endif

const struct dev_pm_ops gpio_ctrl_pm_os = {
	.suspend = NULL,
	.resume = NULL,
};

static struct platform_driver gpio_ctrl_driver = {
	.probe = gpio_ctrl_probe,
	.shutdown = NULL,
	.remove = gpio_ctrl_remove,
	.driver = {
		.owner = THIS_MODULE,
		.name = "gpio_ctrl",
		.pm = &gpio_ctrl_pm_os,
	#ifdef CONFIG_OF
		.of_match_table = gpio_ctrl_of_match,
	#endif
	}
};

static int gpio_ctrl_mod_init(void)
{
	//GPIO_CTRL_FUNC();
	if(platform_driver_register(&gpio_ctrl_driver)!=0)
		{
		//GPIO_CTRL_DEBUG("unable to register gpio_ctrl driver\n");
		return -1;
	}
	return 0;
}

static void gpio_ctrl_mode_exit(void){
	//GPIO_CTRL_FUNC();
	platform_driver_unregister(&gpio_ctrl_driver);
}

module_init(gpio_ctrl_mod_init);
module_exit(gpio_ctrl_mode_exit);

MODULE_DESCRIPTION("Rinlink gpio_gpio_ctrl driver");
MODULE_AUTHOR("maoweihua@rinlink.vip");
MODULE_LICENSE("GPL");



#endif

