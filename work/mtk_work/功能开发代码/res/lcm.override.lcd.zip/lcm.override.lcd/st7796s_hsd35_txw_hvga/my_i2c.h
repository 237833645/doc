#ifndef __MY_I2C_H__
#define __MY_I2C_H__

#ifndef BUILD_LK
#include <linux/delay.h>
#include <linux/printk.h>

#else
#include <platform/mt_gpio.h>
#include <platform/mt_i2c.h>
#include <platform/mt_pmic.h>
#include <cust_gpio_usage.h>
#include <cust_i2c.h>
#endif

#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE  0
#endif


#ifdef BUILD_LK
extern kal_uint32 lt9211_read_byte(kal_uint8 addr, kal_uint8 *dataBuffer);
extern kal_uint32 lt9211_write_byte(kal_uint8 addr, kal_uint8 value);
extern kal_uint32 isl97900_l_write_byte(kal_uint8 addr, kal_uint8 value);
extern kal_uint32 isl97900_l_read_byte(kal_uint8 addr, kal_uint8 *dataBuffer);
extern kal_uint32 isl97900_r_write_byte(kal_uint8 addr, kal_uint8 value);
extern kal_uint32 isl97900_r_read_byte(kal_uint8 addr, kal_uint8 *dataBuffer);
extern kal_uint32 ovp0921_l_write_byte(kal_uint8 addr, kal_uint8 value);
extern kal_uint32 ovp0921_l_read_byte(kal_uint8 addr, kal_uint8 *dataBuffer);
extern kal_uint32 ovp0921_r_write_byte(kal_uint8 addr, kal_uint8 value);
extern kal_uint32 ovp0921_r_read_byte(kal_uint8 addr, kal_uint8 *dataBuffer);

#else
extern int lt9211_read_bytes(unsigned char cmd, unsigned char *returnData);
extern int lt9211_write_bytes(unsigned char cmd, unsigned char writeData);
extern int isl97900_l_write_bytes(unsigned char cmd, unsigned char writeData);
extern int isl97900_l_read_bytes(unsigned char cmd, unsigned char *returnData);
extern int isl97900_r_write_bytes(unsigned char cmd, unsigned char writeData);
extern int isl97900_r_read_bytes(unsigned char cmd, unsigned char *returnData);
extern int ovp0921_l_write_bytes(unsigned char cmd, unsigned char writeData);
extern int ovp0921_l_read_bytes(unsigned char cmd, unsigned char *returnData);
extern int ovp0921_r_write_bytes(unsigned char cmd, unsigned char writeData);
extern int ovp0921_r_read_bytes(unsigned char cmd, unsigned char *returnData);
#endif

#endif
