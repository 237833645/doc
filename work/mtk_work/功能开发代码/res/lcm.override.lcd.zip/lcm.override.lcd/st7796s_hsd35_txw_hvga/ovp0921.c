#include "ovp0921.h"


int ovp0921_suspend(int ch)
{
	int ret = 0;
	return ret;	
}

int ovp0921_resume(int ch)
{
	int ret = 0;
	return ret;	
}


int ovp0921_init(int ch)
{
	int ret = 0;
	return ret;
}
